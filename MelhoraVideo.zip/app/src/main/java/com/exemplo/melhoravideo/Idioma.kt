package com.exemplo.melhoravideo

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

/** Idioma do app (pt/en), salvo nas preferências. Padrão: português se o sistema estiver em português. */
object Idioma {
    private const val PREFS = "config"
    private const val CHAVE = "idioma"

    fun salvo(ctx: Context): String =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(CHAVE, null)
            ?: if (Locale.getDefault().language == "pt") "pt" else "en"

    fun salvar(ctx: Context, codigo: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(CHAVE, codigo).apply()
    }

    /** Devolve um Context com o idioma escolhido (usado na Activity e nas notificações). */
    fun aplicar(base: Context): Context {
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(Locale(salvo(base)))
        return base.createConfigurationContext(cfg)
    }

    /** "Faltam cerca de 16 min", "...1 h 05 min", etc. */
    fun etaTexto(c: Context, seg: Int): String {
        if (seg < 0) return c.getString(R.string.calculando)
        val t = when {
            seg < 60 -> c.getString(R.string.menos_1_min)
            seg < 3600 -> c.getString(R.string.min_fmt, (seg + 30) / 60)
            else -> c.getString(R.string.h_min_fmt, seg / 3600, (seg % 3600) / 60)
        }
        return c.getString(R.string.faltam_fmt, t)
    }
}
