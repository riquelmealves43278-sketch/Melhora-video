package com.exemplo.melhoravideo

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES20
import android.opengl.GLES30
import android.view.Surface
import com.arthenica.ffmpegkit.FFmpegSession
import com.arthenica.ffmpegkit.SessionState
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.nio.ByteBuffer
import java.util.concurrent.FutureTask
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException
import kotlin.math.roundToInt

class Cancelado : RuntimeException("cancelado")

/** O celular tem codificador de hardware para H.264 / H.265? */
object Suporte {
    fun codec(c: Codec): Boolean {
        val mime = when (c) {
            Codec.H264 -> MediaFormat.MIMETYPE_VIDEO_AVC
            Codec.H265 -> MediaFormat.MIMETYPE_VIDEO_HEVC
            Codec.AV1 -> return true // AV1 roda por software no FFmpeg
        }
        return runCatching {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { info ->
                info.isEncoder && info.supportedTypes.any { it.equals(mime, ignoreCase = true) }
            }
        }.getOrDefault(false)
    }
}

/** frameW/H = quadros que saem do FFmpeg; outW/H = vídeo final. Com FSR/Anime4K, o frame é menor que o final. */
class ConfigGpu(
    val frameW: Int, val frameH: Int,
    val outW: Int, val outH: Int,
    val fsr: Boolean,
    val anime: Boolean, val animeArquivos: List<String>,
    val pre: List<String>, val post: List<String>,   // realce na GPU antes / depois da ampliação
    val rcasStops: Float?
)

/** MediaCodec (H.264/H.265 no chip do celular) + MediaMuxer, com o áudio original copiado sem recodificar. */
class Codificador(
    arquivo: File, w: Int, h: Int, fps: Double, h265: Boolean, audioEntrada: File?
) {
    private val mime = if (h265) MediaFormat.MIMETYPE_VIDEO_HEVC else MediaFormat.MIMETYPE_VIDEO_AVC
    private val codec: MediaCodec = MediaCodec.createEncoderByType(mime)
    private val muxer = MediaMuxer(arquivo.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    private val info = MediaCodec.BufferInfo()
    private var trilhaVideo = -1
    private var trilhaAudio = -1
    private var iniciado = false
    private var extratorAudio: MediaExtractor? = null
    val superficie: Surface

    init {
        val fmt = MediaFormat.createVideoFormat(mime, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrateAlvo(w, h, fps, h265))
            setInteger(MediaFormat.KEY_FRAME_RATE, fps.roundToInt().coerceAtLeast(1))
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
            setInteger(MediaFormat.KEY_COLOR_STANDARD, MediaFormat.COLOR_STANDARD_BT709)
            setInteger(MediaFormat.KEY_COLOR_RANGE, MediaFormat.COLOR_RANGE_LIMITED)
            setInteger(MediaFormat.KEY_COLOR_TRANSFER, MediaFormat.COLOR_TRANSFER_SDR_VIDEO)
        }
        codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        superficie = codec.createInputSurface()
        codec.start()
        prepararAudio(audioEntrada)
    }

    private fun prepararAudio(arquivo: File?) {
        if (arquivo == null) return
        runCatching {
            val ex = MediaExtractor()
            ex.setDataSource(arquivo.absolutePath)
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    trilhaAudio = muxer.addTrack(f)
                    ex.selectTrack(i)
                    extratorAudio = ex
                    return
                }
            }
            ex.release()
        }.onFailure { trilhaAudio = -1; extratorAudio = null }
    }

    /** Tira os pedaços prontos do codificador e grava no MP4. */
    fun drenar(fim: Boolean) {
        if (fim) codec.signalEndOfInputStream()
        var espera = 0
        while (true) {
            val idx = codec.dequeueOutputBuffer(info, if (fim) 10_000L else 0L)
            when {
                idx == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!fim) return
                    if (++espera > 1000) throw IllegalStateException("O codificador não terminou")
                }
                idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    trilhaVideo = muxer.addTrack(codec.outputFormat)
                    muxer.start()
                    iniciado = true
                }
                idx >= 0 -> {
                    val buf = codec.getOutputBuffer(idx) ?: throw IllegalStateException("Buffer nulo")
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (info.size > 0 && iniciado) {
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        muxer.writeSampleData(trilhaVideo, buf, info)
                    }
                    codec.releaseOutputBuffer(idx, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
            }
        }
    }

    fun finalizar() {
        drenar(true)
        copiarAudio()
        muxer.stop()
    }

    private fun copiarAudio() {
        val ex = extratorAudio ?: return
        if (trilhaAudio < 0 || !iniciado) return
        val buf = ByteBuffer.allocate(1 shl 20)
        val bi = MediaCodec.BufferInfo()
        while (true) {
            buf.clear()
            val n = ex.readSampleData(buf, 0)
            if (n < 0) break
            val flags = if (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
            bi.set(0, n, ex.sampleTime, flags)
            muxer.writeSampleData(trilhaAudio, buf, bi)
            ex.advance()
        }
    }

    fun liberar() {
        runCatching { codec.stop() }
        runCatching { codec.release() }
        runCatching { muxer.release() }
        runCatching { extratorAudio?.release() }
    }
}

/**
 * OpenGL ES 3.1 desenhando direto na superfície do codificador:
 * YUV -> RGB; depois, se pedido, FSR 1.0 (EASU) ou Anime4K, redimensionamento final (Lanczos) e RCAS (nitidez).
 * As texturas internas seguem a orientação do mpv (linha 0 = topo); a última etapa inverte para o codificador.
 */
class Gpu(private val ctx: Context, superficie: Surface, private val cfg: ConfigGpu) {
    class Tex(val id: Int, val fbo: Int, val w: Int, val h: Int)

    private var dpy: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglCtx: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurf: EGLSurface = EGL14.EGL_NO_SURFACE
    private val locs = HashMap<String, Int>()
    private var vao = 0
    private var progYuv = 0
    private var progBlit = 0
    private var progEasu = 0
    private var progRcas = 0
    private var progLanczos = 0
    private var texY = 0
    private var texU = 0
    private var texV = 0
    private val rgb: Tex
    private var saida1: Tex? = null
    private var saida2: Tex? = null
    private val pool = ArrayList<Tex>()
    private var passosAnime: List<Passo> = emptyList()
    private var prePassos: List<Passo> = emptyList()
    private var postPassos: List<Passo> = emptyList()
    private val programas = HashMap<Passo, Int>()
    private val gpuAmplia = cfg.fsr || cfg.anime

    init {
        iniciarEgl(superficie)
        val a = IntArray(1)
        GLES30.glGenVertexArrays(1, a, 0)
        vao = a[0]
        progYuv = programa(GpuShaders.VERTICE, GpuShaders.YUV_PARA_RGB)
        progBlit = programa(GpuShaders.VERTICE, GpuShaders.COPIA_INVERTIDA)
        rgb = novoAlvo(cfg.frameW, cfg.frameH, false)
        texY = textura(cfg.frameW, cfg.frameH, GLES30.GL_R8, GLES30.GL_RED, GLES20.GL_UNSIGNED_BYTE)
        texU = textura(cfg.frameW / 2, cfg.frameH / 2, GLES30.GL_R8, GLES30.GL_RED, GLES20.GL_UNSIGNED_BYTE)
        texV = textura(cfg.frameW / 2, cfg.frameH / 2, GLES30.GL_R8, GLES30.GL_RED, GLES20.GL_UNSIGNED_BYTE)
        if (gpuAmplia) {
            saida1 = novoAlvo(cfg.outW, cfg.outH, false)
            saida2 = novoAlvo(cfg.outW, cfg.outH, false)
            if (cfg.rcasStops != null) progRcas = programa(GpuShaders.VERTICE, asset("shaders/rcas.frag"))
        }
        if (cfg.fsr) progEasu = programa(GpuShaders.VERTICE, asset("shaders/easu.frag"))
        if (cfg.anime) {
            exigirFloat()
            progLanczos = programa(GpuShaders.VERTICE, GpuShaders.REDIMENSIONA_LANCZOS)
            passosAnime = cfg.animeArquivos.flatMap { Anime4kPlano.analisar(asset(it)) }
        }
        if (cfg.pre.isNotEmpty() || cfg.post.isNotEmpty()) {
            exigirFloat()
            prePassos = cfg.pre.flatMap { Anime4kPlano.analisar(asset(it)) }
            postPassos = cfg.post.flatMap { Anime4kPlano.analisar(asset(it)) }
        }
    }

    private fun iniciarEgl(superficie: Surface) {
        dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val v = IntArray(2)
        check(EGL14.eglInitialize(dpy, v, 0, v, 1)) { "EGL: falha ao iniciar" }
        val attrs = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, 0x0040, // EGL_OPENGL_ES3_BIT_KHR
            0x3142, 1,                          // EGL_RECORDABLE_ANDROID
            EGL14.EGL_NONE
        )
        val cfgs = arrayOfNulls<EGLConfig>(1)
        val n = IntArray(1)
        check(EGL14.eglChooseConfig(dpy, attrs, 0, cfgs, 0, 1, n, 0) && n[0] > 0) { "EGL: sem configuração ES3" }
        eglCtx = EGL14.eglCreateContext(
            dpy, cfgs[0], EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0
        )
        eglSurf = EGL14.eglCreateWindowSurface(dpy, cfgs[0], superficie, intArrayOf(EGL14.EGL_NONE), 0)
        check(EGL14.eglMakeCurrent(dpy, eglSurf, eglSurf, eglCtx)) { "EGL: makeCurrent falhou" }
    }

    /** O Anime4K guarda resultados intermediários em texturas float de 16 bits. */
    private fun exigirFloat() {
        val ext = GLES20.glGetString(GLES20.GL_EXTENSIONS) ?: ""
        val ver = GLES20.glGetString(GLES20.GL_VERSION) ?: ""
        check(
            ver.contains("OpenGL ES 3.2") || ext.contains("GL_EXT_color_buffer_float") ||
                ext.contains("GL_EXT_color_buffer_half_float")
        ) { "A GPU não renderiza em texturas float" }
    }

    private fun asset(caminho: String) = ctx.assets.open(caminho).bufferedReader().use { it.readText() }

    private fun compilar(tipo: Int, fonte: String): Int {
        val s = GLES20.glCreateShader(tipo)
        GLES20.glShaderSource(s, fonte)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(s)
            GLES20.glDeleteShader(s)
            throw IllegalStateException("Shader não compilou: $log")
        }
        return s
    }

    private fun programa(vs: String, fs: String): Int {
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, compilar(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(p, compilar(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw IllegalStateException("Programa não ligou: ${GLES20.glGetProgramInfoLog(p)}")
        return p
    }

    private fun textura(w: Int, h: Int, interno: Int, formato: Int, tipo: Int): Int {
        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, t[0])
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, interno, w, h, 0, formato, tipo, null)
        return t[0]
    }

    private fun novoAlvo(w: Int, h: Int, flutuante: Boolean): Tex {
        val t = if (flutuante) {
            textura(w, h, GLES30.GL_RGBA16F, GLES20.GL_RGBA, GLES30.GL_HALF_FLOAT)
        } else {
            textura(w, h, GLES30.GL_RGBA8, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE)
        }
        val f = IntArray(1)
        GLES20.glGenFramebuffers(1, f, 0)
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, f[0])
        GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, t, 0)
        check(GLES20.glCheckFramebufferStatus(GLES20.GL_FRAMEBUFFER) == GLES20.GL_FRAMEBUFFER_COMPLETE) { "Framebuffer incompleto" }
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
        return Tex(t, f[0], w, h)
    }

    private fun pegarFloat(w: Int, h: Int, emUso: Set<Tex>): Tex =
        pool.firstOrNull { it.w == w && it.h == h && it !in emUso } ?: novoAlvo(w, h, true).also { pool += it }

    private fun loc(p: Int, nome: String) = locs.getOrPut("$p/$nome") { GLES20.glGetUniformLocation(p, nome) }

    private fun ligar(unidade: Int, tex: Int) {
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0 + unidade)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
    }

    private fun usarAlvo(fbo: Int, w: Int, h: Int) {
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo)
        GLES20.glViewport(0, 0, w, h)
    }

    private fun triangulo() {
        GLES30.glBindVertexArray(vao)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 3)
    }

    private fun parte(tex: Int, unidade: Int, w: Int, h: Int, dados: ByteBuffer, deslocamento: Int) {
        ligar(unidade, tex)
        dados.position(deslocamento)
        GLES20.glTexSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, w, h, GLES30.GL_RED, GLES20.GL_UNSIGNED_BYTE, dados)
    }

    /** Envia um quadro yuv420p (Y, depois U, depois V) para as texturas. */
    fun enviar(quadro: ByteBuffer) {
        GLES20.glPixelStorei(GLES20.GL_UNPACK_ALIGNMENT, 1)
        val ySize = cfg.frameW * cfg.frameH
        val cw = cfg.frameW / 2
        val ch = cfg.frameH / 2
        parte(texY, 0, cfg.frameW, cfg.frameH, quadro, 0)
        parte(texU, 1, cw, ch, quadro, ySize)
        parte(texV, 2, cw, ch, quadro, ySize + cw * ch)
    }

    private fun passeYuv() {
        usarAlvo(rgb.fbo, rgb.w, rgb.h)
        GLES20.glUseProgram(progYuv)
        ligar(0, texY); ligar(1, texU); ligar(2, texV)
        GLES20.glUniform1i(loc(progYuv, "ty"), 0)
        GLES20.glUniform1i(loc(progYuv, "tu"), 1)
        GLES20.glUniform1i(loc(progYuv, "tv"), 2)
        triangulo()
    }

    private fun passeEasu(src: Tex, dst: Tex) {
        usarAlvo(dst.fbo, dst.w, dst.h)
        GLES20.glUseProgram(progEasu)
        ligar(0, src.id)
        GLES20.glUniform1i(loc(progEasu, "tex"), 0)
        GLES20.glUniform4f(loc(progEasu, "uSizes"), src.w.toFloat(), src.h.toFloat(), dst.w.toFloat(), dst.h.toFloat())
        triangulo()
    }

    private fun passeLanczos(src: Tex, dst: Tex) {
        usarAlvo(dst.fbo, dst.w, dst.h)
        GLES20.glUseProgram(progLanczos)
        ligar(0, src.id)
        GLES20.glUniform1i(loc(progLanczos, "tex"), 0)
        GLES20.glUniform2f(loc(progLanczos, "uIn"), src.w.toFloat(), src.h.toFloat())
        GLES20.glUniform2f(loc(progLanczos, "uOut"), dst.w.toFloat(), dst.h.toFloat())
        triangulo()
    }

    private fun passeRcas(src: Tex, dst: Tex, stops: Float) {
        usarAlvo(dst.fbo, dst.w, dst.h)
        GLES20.glUseProgram(progRcas)
        ligar(0, src.id)
        GLES20.glUniform1i(loc(progRcas, "tex"), 0)
        GLES20.glUniform1f(loc(progRcas, "uStops"), stops)
        triangulo()
    }

    private fun passeBlit(src: Tex) {
        usarAlvo(0, cfg.outW, cfg.outH)
        GLES20.glUseProgram(progBlit)
        ligar(0, src.id)
        GLES20.glUniform1i(loc(progBlit, "tex"), 0)
        triangulo()
    }

    /** Roda a sequência de passes do Anime4K (mesma lógica do mpv: MAIN primeiro, depois PREKERNEL). */
    private fun executar(passos: List<Passo>, entrada: Tex): Tex {
        var main = entrada
        val nativa = entrada
        val guardadas = HashMap<String, Tex>()
        fun tamanho(n: String): Pair<Int, Int>? = when (n) {
            "MAIN", "HOOKED" -> main.w to main.h
            "NATIVE" -> nativa.w to nativa.h
            "OUTPUT" -> cfg.outW to cfg.outH
            else -> guardadas[n]?.let { it.w to it.h }
        }
        for (estagio in listOf("MAIN", "PREKERNEL")) {
            for (p in passos) {
                if (p.hook != estagio) continue
                val cond = p.quando
                if (cond != null) {
                    val v = Anime4kPlano.avaliar(cond, ::tamanho)
                    if (v == null || v == 0.0) continue
                }
                val w = p.largura?.let { Anime4kPlano.avaliar(it, ::tamanho) }?.toInt() ?: main.w
                val h = p.altura?.let { Anime4kPlano.avaliar(it, ::tamanho) }?.toInt() ?: main.h
                val ligadas = ArrayList<Pair<String, Tex>>()
                var faltou = false
                for (n in p.binds.distinct()) {
                    val t = when (n) {
                        "HOOKED", "MAIN" -> main
                        "NATIVE" -> nativa
                        else -> guardadas[n]
                    }
                    if (t == null) { faltou = true; break }
                    ligadas += n to t
                }
                if (faltou) continue
                val emUso = HashSet<Tex>()
                emUso += main; emUso += nativa; emUso.addAll(guardadas.values)
                val destino = pegarFloat(w, h, emUso)
                val prog = programas.getOrPut(p) { programa(GpuShaders.VERTICE, Anime4kPlano.montarShader(p)) }
                usarAlvo(destino.fbo, w, h)
                GLES20.glUseProgram(prog)
                ligadas.forEachIndexed { i, par ->
                    ligar(i, par.second.id)
                    GLES20.glUniform1i(loc(prog, "A4K_tex_${par.first}"), i)
                    GLES20.glUniform2f(loc(prog, "A4K_size_${par.first}"), par.second.w.toFloat(), par.second.h.toFloat())
                }
                triangulo()
                val salvar = p.salvar ?: "MAIN"
                if (salvar == "MAIN" || salvar == "HOOKED") main = destino else guardadas[salvar] = destino
            }
        }
        return main
    }

    fun desenhar() {
        passeYuv()
        var atual = rgb
        if (prePassos.isNotEmpty()) atual = executar(prePassos, atual)
        if (cfg.fsr) {
            passeEasu(atual, saida1!!)
            atual = saida1!!
        } else if (cfg.anime) {
            atual = executar(passosAnime, atual)
            if (atual.w != cfg.outW || atual.h != cfg.outH) {
                passeLanczos(atual, saida1!!)
                atual = saida1!!
            }
        }
        if (postPassos.isNotEmpty()) atual = executar(postPassos, atual)
        val stops = cfg.rcasStops
        if (gpuAmplia && stops != null) {
            val destino = if (atual === saida1) saida2!! else saida1!!
            passeRcas(atual, destino, stops)
            atual = destino
        }
        passeBlit(atual)
    }

    fun tempo(ns: Long) { EGLExt.eglPresentationTimeANDROID(dpy, eglSurf, ns) }
    fun trocar() { EGL14.eglSwapBuffers(dpy, eglSurf) }

    fun liberar() {
        runCatching {
            if (dpy != EGL14.EGL_NO_DISPLAY) {
                EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                if (eglSurf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, eglSurf)
                if (eglCtx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(dpy, eglCtx)
                EGL14.eglReleaseThread()
                EGL14.eglTerminate(dpy)
            }
        }
    }
}

/** Abre o pipe de leitura; se o FFmpeg morrer antes de abrir o lado de escrita, destrava a abertura. */
private fun abrirPipe(pipe: String, sessao: FFmpegSession): InputStream {
    val tarefa = FutureTask<InputStream> { FileInputStream(pipe) }
    Thread(tarefa, "abrir-pipe").start()
    while (true) {
        try {
            return tarefa.get(100, TimeUnit.MILLISECONDS)
        } catch (_: TimeoutException) {
        }
        if (sessao.state == SessionState.COMPLETED || sessao.state == SessionState.FAILED) {
            runCatching { FileOutputStream(pipe).close() }
            return tarefa.get(2, TimeUnit.SECONDS)
        }
    }
}

private fun lerQuadro(entrada: InputStream, buf: ByteArray): Boolean {
    var off = 0
    while (off < buf.size) {
        val n = entrada.read(buf, off, buf.size - off)
        if (n < 0) return false
        off += n
    }
    return true
}

/**
 * Lê os quadros brutos do pipe, passa pela GPU e grava com o codificador do celular.
 * Devolve quantos quadros foram gravados.
 */
fun executarGpu(
    ctx: Context, pipe: String, sessao: FFmpegSession, audioEntrada: File, saida: File,
    cfg: ConfigGpu, fps: Double, h265: Boolean,
    cancelado: () -> Boolean, aoProgredir: (Double) -> Unit
): Long {
    val entrada = abrirPipe(pipe, sessao)
    var enc: Codificador? = null
    var gpu: Gpu? = null
    try {
        enc = Codificador(saida, cfg.outW, cfg.outH, fps, h265, audioEntrada)
        gpu = Gpu(ctx, enc.superficie, cfg)
        val tamanho = cfg.frameW * cfg.frameH + 2 * (cfg.frameW / 2) * (cfg.frameH / 2)
        val bytes = ByteArray(tamanho)
        val direto = ByteBuffer.allocateDirect(tamanho)
        var quadros = 0L
        while (true) {
            if (cancelado()) throw Cancelado()
            if (!lerQuadro(entrada, bytes)) break
            direto.clear()
            direto.put(bytes)
            gpu.enviar(direto)
            gpu.desenhar()
            gpu.tempo((quadros * 1_000_000_000.0 / fps).toLong())
            gpu.trocar()
            enc.drenar(false)
            quadros++
            aoProgredir(quadros / fps * 1000.0)
        }
        if (quadros == 0L) throw IllegalStateException("O FFmpeg não enviou nenhum quadro")
        enc.finalizar()
        return quadros
    } finally {
        runCatching { entrada.close() }
        gpu?.liberar()
        enc?.liberar()
    }
}
