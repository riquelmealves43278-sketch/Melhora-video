package com.exemplo.melhoravideo

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.work.*
import kotlinx.coroutines.flow.emptyFlow
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface { Tela() } } }
    }
}

@Composable
fun Tela() {
    val ctx = LocalContext.current
    val wm = remember { WorkManager.getInstance(ctx) }
    val alturas = listOf(720, 1080, 1440, 2160)
    val fpsLista = listOf(30, 60, 90, 120)

    var uri by remember { mutableStateOf<Uri?>(null) }
    var alturaIdx by remember { mutableIntStateOf(1) }
    var fpsIdx by remember { mutableIntStateOf(1) }
    var ampliar by remember { mutableStateOf(true) }
    var gerar by remember { mutableStateOf(true) }
    var trabalhoId by remember { mutableStateOf<UUID?>(null) }

    val info by remember(trabalhoId) {
        trabalhoId?.let { wm.getWorkInfoByIdFlow(it) } ?: emptyFlow()
    }.collectAsState(initial = null)

    val iniciar = {
        val dados = workDataOf(
            "uri" to uri.toString(), "altura" to alturas[alturaIdx], "fps" to fpsLista[fpsIdx],
            "ampliar" to ampliar, "gerar" to gerar
        )
        val req = OneTimeWorkRequestBuilder<VideoWorker>().setInputData(dados).build()
        wm.enqueue(req); trabalhoId = req.id
    }
    val pedirNotificacao = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { iniciar() } // inicia mesmo se negar (só some a notificação)
    val escolher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { u ->
        u?.let { ctx.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        uri = u
    }

    val estado = info?.state
    val rodando = estado == WorkInfo.State.RUNNING || estado == WorkInfo.State.ENQUEUED
    val progresso = info?.progress?.getInt("p", 0) ?: 0

    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Melhorar vídeo", style = MaterialTheme.typography.headlineMedium)
        OutlinedButton(onClick = { escolher.launch(arrayOf("video/*")) }, enabled = !rodando) {
            Text(if (uri == null) "Escolher vídeo" else "Vídeo selecionado ✓")
        }
        Text("O que melhorar")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            // Pelo menos um dos dois fica sempre ligado
            Modo("Resolução", ampliar, !rodando && (!ampliar || gerar), Modifier.weight(1f)) { ampliar = !ampliar }
            Modo("Gerar quadros", gerar, !rodando && (!gerar || ampliar), Modifier.weight(1f)) { gerar = !gerar }
        }
        if (ampliar) {
            Text("Resolução de saída")
            Opcao(alturas.map { "${it}p" }, alturaIdx, !rodando) { alturaIdx = it }
        }
        if (gerar) {
            Text("FPS de saída")
            Opcao(fpsLista.map { "$it" }, fpsIdx, !rodando) { fpsIdx = it }
        }
        Spacer(Modifier.weight(1f))

        when {
            rodando -> {
                Text("Processando… $progresso%")
                LinearProgressIndicator(progress = { progresso / 100f }, modifier = Modifier.fillMaxWidth())
                OutlinedButton(onClick = { trabalhoId?.let { wm.cancelWorkById(it) } }) { Text("Cancelar") }
            }
            estado == WorkInfo.State.SUCCEEDED -> Text("Pronto! Salvo em Movies/Melhorados na galeria.")
            estado == WorkInfo.State.FAILED -> Text("Falhou. Tente outro vídeo ou menos opções.")
        }
        Button(
            onClick = {
                if (Build.VERSION.SDK_INT >= 33) pedirNotificacao.launch(Manifest.permission.POST_NOTIFICATIONS)
                else iniciar()
            },
            enabled = uri != null && !rodando,
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("Iniciar em segundo plano") }
    }
}

@Composable
fun Opcao(titulos: List<String>, sel: Int, ativo: Boolean, aoEscolher: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        titulos.forEachIndexed { i, t ->
            FilterChip(selected = i == sel, onClick = { aoEscolher(i) }, label = { Text(t) }, enabled = ativo)
        }
    }
}

@Composable
fun Modo(texto: String, ativo: Boolean, habilitado: Boolean, modifier: Modifier, aoClicar: () -> Unit) {
    if (ativo) Button(onClick = aoClicar, enabled = habilitado, modifier = modifier.height(48.dp)) { Text(texto) }
    else OutlinedButton(onClick = aoClicar, enabled = habilitado, modifier = modifier.height(48.dp)) { Text(texto) }
}
