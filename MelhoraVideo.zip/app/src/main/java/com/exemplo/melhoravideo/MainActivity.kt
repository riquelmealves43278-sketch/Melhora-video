package com.exemplo.melhoravideo

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.work.*
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.FFprobeKit
import kotlinx.coroutines.flow.emptyFlow
import java.util.Locale
import java.util.UUID
import kotlin.math.abs
import kotlin.math.roundToInt

private val Fundo = Color(0xFF0F1419)
private val Cartao = Color(0xFF1A2129)
private val Linha = Color(0xFF2B3640)
private val Texto = Color(0xFFE8ECF1)
private val Mudo = Color(0xFFA3ADB9)
private val Acento = Color(0xFFFFB547)
private val NoAcento = Color(0xFF1A1200)

class MainActivity : ComponentActivity() {
    // Aplica o idioma escolhido nas configurações do app
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Idioma.aplicar(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Acento, onPrimary = NoAcento,
                    background = Fundo, surface = Fundo,
                    onBackground = Texto, onSurface = Texto,
                    secondaryContainer = Acento, onSecondaryContainer = NoAcento,
                    surfaceVariant = Cartao, onSurfaceVariant = Mudo,
                    outline = Linha, outlineVariant = Linha
                )
            ) { Surface(color = Fundo) { Tela() } }
        }
    }
}

private tailrec fun Context.ativ(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.ativ()
    else -> null
}

data class InfoVideo(
    val nome: String, val largura: Int, val altura: Int,
    val fps: String, val duracao: String, val miniatura: Bitmap?
)

private fun fpsTexto(r: String?): String {
    val p = r?.split("/") ?: return "?"
    val n = p.getOrNull(0)?.toDoubleOrNull() ?: return "?"
    val d = p.getOrNull(1)?.toDoubleOrNull() ?: 1.0
    if (d == 0.0) return "?"
    val f = n / d
    return if (abs(f - f.roundToInt()) < 0.01) "${f.roundToInt()}" else String.format(Locale.US, "%.2f", f)
}

/** Lê resolução, FPS, duração e uma miniatura do vídeo escolhido (em segundo plano). */
fun lerInfo(ctx: Context, uri: Uri, aoTerminar: (InfoVideo?) -> Unit) {
    val nome = ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
        ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: "video"
    val caminho = FFmpegKitConfig.getSafParameterForRead(ctx, uri)
    FFprobeKit.getMediaInformationAsync(caminho) { sessao ->
        val mi = sessao.mediaInformation
        val v = mi?.streams?.firstOrNull { it.type == "video" }
        if (mi == null || v == null) {
            aoTerminar(null)
        } else {
            val seg = (mi.duration?.toDoubleOrNull() ?: 0.0).toInt()
            val miniatura = runCatching {
                val r = MediaMetadataRetriever()
                r.setDataSource(ctx, uri)
                val b = r.getFrameAtTime(0)
                r.release(); b
            }.getOrNull()
            aoTerminar(
                InfoVideo(
                    nome, (v.width ?: 0L).toInt(), (v.height ?: 0L).toInt(),
                    fpsTexto(v.averageFrameRate), String.format(Locale.US, "%d:%02d", seg / 60, seg % 60), miniatura
                )
            )
        }
    }
}

@Composable
fun Tela() {
    val ctx = LocalContext.current
    val wm = remember { WorkManager.getInstance(ctx) }
    val alturas = listOf(720, 1080, 1440, 2160)
    val fpsLista = listOf(30, 60, 90, 120)
    val metodosAmp = MetodoAmpliacao.entries
    val metodosQua = MetodoQuadros.entries
    val nomesAmp = listOf(R.string.amp_lanczos_nitidez, R.string.amp_lanczos_cas, R.string.amp_lanczos)
    val nomesQua = listOf(R.string.qua_rapido, R.string.qua_qualidade)

    // rememberSaveable: o que o usuário escolheu sobrevive à troca de idioma (a tela é recriada)
    var tela by rememberSaveable { mutableStateOf("home") }
    var uri by rememberSaveable { mutableStateOf<Uri?>(null) }
    var alturaIdx by rememberSaveable { mutableStateOf(1) }
    var fpsIdx by rememberSaveable { mutableStateOf(1) }
    var ampIdx by rememberSaveable { mutableStateOf(0) }
    var quaIdx by rememberSaveable { mutableStateOf(1) }
    var ampliar by rememberSaveable { mutableStateOf(true) }
    var gerar by rememberSaveable { mutableStateOf(true) }
    var trabalhoId by rememberSaveable { mutableStateOf<UUID?>(null) }
    var aviso by rememberSaveable { mutableStateOf(false) }
    var infoVideo by remember { mutableStateOf<InfoVideo?>(null) }

    LaunchedEffect(uri) {
        infoVideo = null
        uri?.let { u -> lerInfo(ctx, u) { infoVideo = it } }
    }

    val info by remember(trabalhoId) {
        trabalhoId?.let { wm.getWorkInfoByIdFlow(it) } ?: emptyFlow()
    }.collectAsState(initial = null)

    val iniciar = {
        val dados = workDataOf(
            "uri" to uri.toString(), "altura" to alturas[alturaIdx], "fps" to fpsLista[fpsIdx],
            "ampliar" to ampliar, "gerar" to gerar,
            "mamp" to metodosAmp[ampIdx].name, "mqua" to metodosQua[quaIdx].name
        )
        val req = OneTimeWorkRequestBuilder<VideoWorker>().setInputData(dados).build()
        wm.enqueue(req); trabalhoId = req.id
    }
    val pedirNotificacao = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { iniciar() } // inicia mesmo se negar (só some a notificação)
    val comecar = {
        if (Build.VERSION.SDK_INT >= 33) pedirNotificacao.launch(Manifest.permission.POST_NOTIFICATIONS)
        else iniciar()
    }
    val escolher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { u ->
        u?.let { ctx.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        uri = u
    }

    BackHandler(enabled = tela == "config") { tela = "home" }

    if (tela == "config") {
        Config { tela = "home" }
        return
    }

    val estado = info?.state
    val rodando = estado == WorkInfo.State.RUNNING || estado == WorkInfo.State.ENQUEUED
    val progresso = info?.progress?.getInt("p", 0) ?: 0
    val eta = info?.progress?.getInt("eta", -1) ?: -1
    val saida = listOf(
        if (ampliar) "${alturas[alturaIdx]}p" else stringResource(R.string.resolucao_original),
        if (gerar) "${fpsLista[fpsIdx]} FPS" else stringResource(R.string.fps_original)
    ).joinToString(" · ")

    if (aviso) {
        AlertDialog(
            onDismissRequest = { aviso = false },
            containerColor = Cartao, titleContentColor = Texto, textContentColor = Mudo,
            title = { Text(stringResource(R.string.aviso_titulo)) },
            text = { Text(stringResource(R.string.aviso_texto)) },
            confirmButton = { TextButton(onClick = { aviso = false; comecar() }) { Text(stringResource(R.string.continuar)) } },
            dismissButton = { TextButton(onClick = { aviso = false }) { Text(stringResource(R.string.cancelar)) } }
        )
    }

    Column(Modifier.fillMaxSize().systemBarsPadding().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text(stringResource(R.string.subtitulo), color = Mudo)
                }
                TextButton(onClick = { tela = "config" }, enabled = !rodando) { Text(stringResource(R.string.configuracoes)) }
            }
            CartaoVideo(infoVideo, uri != null, saida)
            OutlinedButton(onClick = { escolher.launch(arrayOf("video/*")) }, enabled = !rodando, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(if (uri == null) R.string.escolher_video else R.string.trocar_video))
            }
            Rotulo(stringResource(R.string.o_que_melhorar))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Pelo menos um dos dois fica sempre ligado
                Modo(stringResource(R.string.modo_resolucao), ampliar, !rodando && (!ampliar || gerar), Modifier.weight(1f)) { ampliar = !ampliar }
                Modo(stringResource(R.string.modo_quadros), gerar, !rodando && (!gerar || ampliar), Modifier.weight(1f)) { gerar = !gerar }
            }
            if (ampliar) {
                Rotulo(stringResource(R.string.resolucao_saida))
                Opcao(alturas.map { "${it}p" }, alturaIdx, !rodando) { alturaIdx = it }
                Rotulo(stringResource(R.string.metodo_ampliacao))
                Opcao(nomesAmp.map { stringResource(it) }, ampIdx, !rodando) { ampIdx = it }
            }
            if (gerar) {
                Rotulo(stringResource(R.string.fps_saida))
                Opcao(fpsLista.map { "$it" }, fpsIdx, !rodando) { fpsIdx = it }
                Rotulo(stringResource(R.string.metodo_quadros))
                Opcao(nomesQua.map { stringResource(it) }, quaIdx, !rodando) { quaIdx = it }
            }
        }

        when {
            rodando -> {
                Text(stringResource(R.string.processando_fmt, progresso))
                LinearProgressIndicator(progress = { progresso / 100f }, modifier = Modifier.fillMaxWidth())
                Text(Idioma.etaTexto(ctx, eta), color = Mudo, style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = { trabalhoId?.let { wm.cancelWorkById(it) } }, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.cancelar))
                }
            }
            estado == WorkInfo.State.SUCCEEDED -> Text(stringResource(R.string.pronto))
            estado == WorkInfo.State.FAILED -> Text(stringResource(R.string.falhou))
        }
        Button(
            onClick = { aviso = true },
            enabled = uri != null && !rodando,
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text(stringResource(R.string.iniciar)) }
    }
}

@Composable
fun Config(aoVoltar: () -> Unit) {
    val ctx = LocalContext.current
    val atual = remember { Idioma.salvo(ctx) }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        TextButton(onClick = aoVoltar) { Text("←  " + stringResource(R.string.voltar)) }
        Text(stringResource(R.string.configuracoes), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Rotulo(stringResource(R.string.idioma))
        Opcao(
            listOf(stringResource(R.string.idioma_pt), stringResource(R.string.idioma_en)),
            if (atual == "pt") 0 else 1, true
        ) { i ->
            Idioma.salvar(ctx, if (i == 0) "pt" else "en")
            ctx.ativ()?.recreate()
        }
    }
}

@Composable
fun Rotulo(texto: String) = Text(texto, color = Mudo, fontWeight = FontWeight.SemiBold)

@Composable
fun CartaoVideo(info: InfoVideo?, escolhido: Boolean, saida: String) {
    Surface(color = Cartao, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(72.dp).clip(RoundedCornerShape(12.dp)).background(Linha)) {
                info?.miniatura?.let {
                    Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                }
            }
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    info?.nome ?: stringResource(if (escolhido) R.string.lendo_video else R.string.nenhum_video),
                    fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    if (info != null) "${info.largura}×${info.altura} · ${info.fps} FPS · ${info.duracao}"
                    else stringResource(R.string.toque_escolher),
                    color = Mudo, style = MaterialTheme.typography.bodySmall
                )
                if (info != null) {
                    Text(stringResource(R.string.saida_fmt, saida), color = Acento, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Opcao(titulos: List<String>, sel: Int, ativo: Boolean, aoEscolher: (Int) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        titulos.forEachIndexed { i, t ->
            FilterChip(selected = i == sel, onClick = { aoEscolher(i) }, label = { Text(t) }, enabled = ativo)
        }
    }
}

@Composable
fun Modo(texto: String, ativo: Boolean, habilitado: Boolean, modifier: Modifier, aoClicar: () -> Unit) {
    if (ativo) Button(onClick = aoClicar, enabled = habilitado, modifier = modifier.height(48.dp)) { Text(texto) }
    else OutlinedButton(onClick = aoClicar, enabled = habilitado, modifier = modifier.height(48.dp)) { Text(texto) }
}
