package com.exemplo.melhoravideo

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.work.*
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.FFprobeKit
import kotlinx.coroutines.flow.emptyFlow
import java.util.Locale
import java.util.UUID
import kotlin.math.abs
import kotlin.math.roundToInt

private val Fundo = Color(0xFF0F1419)
private val Cartao = Color(0xFF1A2129)
private val Linha = Color(0xFF2B3640)
private val Texto = Color(0xFFE8ECF1)
private val Mudo = Color(0xFFA3ADB9)
private val Acento = Color(0xFFFFB547)
private val NoAcento = Color(0xFF1A1200)
private val Verde = Color(0xFF7BD88F)

class MainActivity : ComponentActivity() {
    // Aplica o idioma escolhido nas configurações do app
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Idioma.aplicar(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Acento, onPrimary = NoAcento,
                    background = Fundo, surface = Fundo,
                    onBackground = Texto, onSurface = Texto,
                    secondaryContainer = Acento, onSecondaryContainer = NoAcento,
                    surfaceVariant = Cartao, onSurfaceVariant = Mudo,
                    outline = Linha, outlineVariant = Linha
                )
            ) { Surface(color = Fundo) { Tela() } }
        }
    }
}

private tailrec fun Context.ativ(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.ativ()
    else -> null
}

data class InfoVideo(
    val nome: String, val largura: Int, val altura: Int,
    val fps: String, val duracao: String, val miniatura: Bitmap?
)

private fun fpsTexto(r: String?): String {
    val p = r?.split("/") ?: return "?"
    val n = p.getOrNull(0)?.toDoubleOrNull() ?: return "?"
    val d = p.getOrNull(1)?.toDoubleOrNull() ?: 1.0
    if (d == 0.0) return "?"
    val f = n / d
    return if (abs(f - f.roundToInt()) < 0.01) "${f.roundToInt()}" else String.format(Locale.US, "%.2f", f)
}

/** Lê resolução, FPS, duração e uma miniatura do vídeo escolhido (em segundo plano). */
fun lerInfo(ctx: Context, uri: Uri, aoTerminar: (InfoVideo?) -> Unit) {
    val nome = ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
        ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: "video"
    val caminho = FFmpegKitConfig.getSafParameterForRead(ctx, uri)
    FFprobeKit.getMediaInformationAsync(caminho) { sessao ->
        val mi = sessao.mediaInformation
        val v = mi?.streams?.firstOrNull { it.type == "video" }
        if (mi == null || v == null) {
            aoTerminar(null)
        } else {
            val seg = (mi.duration?.toDoubleOrNull() ?: 0.0).toInt()
            val miniatura = runCatching {
                val r = MediaMetadataRetriever()
                r.setDataSource(ctx, uri)
                val b = r.getFrameAtTime(0)
                r.release(); b
            }.getOrNull()
            aoTerminar(
                InfoVideo(
                    nome, (v.width ?: 0L).toInt(), (v.height ?: 0L).toInt(),
                    fpsTexto(v.averageFrameRate), String.format(Locale.US, "%d:%02d", seg / 60, seg % 60), miniatura
                )
            )
        }
    }
}

/** Tudo o que o usuário escolheu. Guardado como texto/números para sobreviver à troca de idioma. */
class Escolhas {
    var tela by mutableStateOf("home") // home, config, ajustes
    var uriTexto by mutableStateOf<String?>(null)
    var alturaIdx by mutableStateOf(1)
    var fpsIdx by mutableStateOf(1)
    var ampIdx by mutableStateOf(0)      // 0 Lanczos, 1 FSR, 2 Vizinho
    var nitIdx by mutableStateOf(0)      // Unsharp, CAS, Nenhuma
    var rcasIdx by mutableStateOf(1)     // Desligada, Leve, Média, Forte
    var quaIdx by mutableStateOf(2)      // Blend, Framerate, Movimento
    var nivelIdx by mutableStateOf(1)    // Rápido, Equilibrado, Qualidade, 2D
    var codecIdx by mutableStateOf(0)    // H264, H265, AV1
    var animeModoIdx by mutableStateOf(0)  // A, B, C
    var animeQualIdx by mutableStateOf(0)  // Rápida, Alta
    var limpezaIdx by mutableStateOf(0)    // Desligada, Leve, Média, Forte
    var ruidoIdx by mutableStateOf(0)      // Desligado, Média, Mediana, Moda
    var deblurIdx by mutableStateOf(0)     // Desligado, DoG, Original
    var quandoIdx by mutableStateOf(1)     // Antes, Depois, Ambos
    var ampliar by mutableStateOf(true)
    var gerar by mutableStateOf(true)
    var trabalhoTexto by mutableStateOf<String?>(null)

    companion object {
        val Saver: Saver<Escolhas, Any> = listSaver<Escolhas, Any?>(
            save = {
                listOf(
                    it.tela, it.uriTexto, it.alturaIdx, it.fpsIdx, it.ampIdx, it.nitIdx, it.rcasIdx,
                    it.quaIdx, it.nivelIdx, it.codecIdx, it.ampliar, it.gerar, it.trabalhoTexto,
                    it.animeModoIdx, it.animeQualIdx, it.limpezaIdx, it.ruidoIdx, it.deblurIdx, it.quandoIdx
                )
            },
            restore = { l ->
                Escolhas().apply {
                    tela = l[0] as String
                    uriTexto = l[1] as String?
                    alturaIdx = l[2] as Int; fpsIdx = l[3] as Int; ampIdx = l[4] as Int
                    nitIdx = l[5] as Int; rcasIdx = l[6] as Int; quaIdx = l[7] as Int
                    nivelIdx = l[8] as Int; codecIdx = l[9] as Int
                    ampliar = l[10] as Boolean; gerar = l[11] as Boolean
                    trabalhoTexto = l[12] as String?
                    animeModoIdx = l[13] as Int; animeQualIdx = l[14] as Int
                    limpezaIdx = l[15] as Int; ruidoIdx = l[16] as Int; deblurIdx = l[17] as Int; quandoIdx = l[18] as Int
                }
            }
        )
    }
}

@Composable
fun Tela() {
    val ctx = LocalContext.current
    val wm = remember { WorkManager.getInstance(ctx) }
    val e = rememberSaveable(saver = Escolhas.Saver) { Escolhas() }
    val alturas = listOf(720, 1080, 1440, 2160)
    val fpsLista = listOf(30, 60, 90, 120)
    val codecs = Codec.entries // H264, H265, AV1
    val suporte = remember { listOf(Suporte.codec(Codec.H264), Suporte.codec(Codec.H265), true) }
    var aviso by rememberSaveable { mutableStateOf(false) }
    var ajuda by rememberSaveable { mutableStateOf(false) }
    var infoVideo by remember { mutableStateOf<InfoVideo?>(null) }

    LaunchedEffect(Unit) {
        if (!suporte[0]) e.codecIdx = if (suporte[1]) 1 else 2
    }
    LaunchedEffect(e.uriTexto) {
        infoVideo = null
        e.uriTexto?.let { t -> lerInfo(ctx, Uri.parse(t)) { infoVideo = it } }
    }

    val trabalho = e.trabalhoTexto?.let { UUID.fromString(it) }
    val info by remember(e.trabalhoTexto) {
        trabalho?.let { wm.getWorkInfoByIdFlow(it) } ?: emptyFlow()
    }.collectAsState(initial = null)
    val estado = info?.state
    val rodando = estado == WorkInfo.State.RUNNING || estado == WorkInfo.State.ENQUEUED
    val concluido = estado == WorkInfo.State.SUCCEEDED
    val falhou = estado == WorkInfo.State.FAILED
    val progresso = info?.progress?.getInt("p", 0) ?: 0
    val eta = info?.progress?.getInt("eta", -1) ?: -1
    val quadro = info?.progress?.getInt("q", 0) ?: 0
    val totalQuadros = info?.progress?.getInt("t", 0) ?: 0

    // FSR roda na GPU e não existe com AV1: nesse caso o app usa H.265 (ou H.264)
    val escalaGpu = e.ampliar && (e.ampIdx == 1 || e.ampIdx == 3)
    val realceAtivo = e.ruidoIdx != 0 || e.deblurIdx != 0
    val fsrAtivo = escalaGpu || realceAtivo // usa a GPU: precisa de H.264/H.265
    val codecIdxEf = if (fsrAtivo && e.codecIdx == 2) (if (suporte[1]) 1 else 0) else e.codecIdx
    val saidaTxt = listOf(
        if (e.ampliar) "${alturas[e.alturaIdx]}p" else stringResource(R.string.resolucao_original),
        if (e.gerar) "${fpsLista[e.fpsIdx]} FPS" else stringResource(R.string.fps_original)
    ).joinToString(" · ")

    val iniciar = {
        val dados = workDataOf(
            "uri" to e.uriTexto, "altura" to alturas[e.alturaIdx], "fps" to fpsLista[e.fpsIdx],
            "ampliar" to e.ampliar, "gerar" to e.gerar,
            "amp" to MetodoAmpliacao.entries[e.ampIdx].name, "nit" to Nitidez.entries[e.nitIdx].name,
            "rcas" to Rcas.entries[e.rcasIdx].name, "qua" to MetodoQuadros.entries[e.quaIdx].name,
            "nivel" to NivelMovimento.entries[e.nivelIdx].name, "codec" to codecs[codecIdxEf].name,
            "anm" to Anime4kModo.entries[e.animeModoIdx].name, "anq" to Anime4kQualidade.entries[e.animeQualIdx].name,
            "lmp" to Limpeza.entries[e.limpezaIdx].name, "dns" to RuidoGpu.entries[e.ruidoIdx].name,
            "dbl" to DeblurGpu.entries[e.deblurIdx].name, "qnd" to QuandoRealce.entries[if (escalaGpu) e.quandoIdx else 1].name
        )
        val req = OneTimeWorkRequestBuilder<VideoWorker>().setInputData(dados).build()
        wm.enqueue(req); e.trabalhoTexto = req.id.toString()
    }
    val pedirNotificacao = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { iniciar() } // inicia mesmo se negar (só some a notificação)
    val comecar = {
        if (Build.VERSION.SDK_INT >= 33) pedirNotificacao.launch(Manifest.permission.POST_NOTIFICATIONS)
        else iniciar()
    }
    val escolher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            e.uriTexto = u.toString()
        }
    }
    val abrirSeletor = { escolher.launch(arrayOf("video/*")) }

    BackHandler(enabled = !rodando && !concluido && e.tela != "home") { e.tela = "home" }

    if (aviso) {
        AlertDialog(
            onDismissRequest = { aviso = false },
            containerColor = Cartao, titleContentColor = Texto, textContentColor = Mudo,
            title = { Text(stringResource(R.string.aviso_titulo)) },
            text = { Text(stringResource(R.string.aviso_texto)) },
            confirmButton = { TextButton(onClick = { aviso = false; comecar() }) { Text(stringResource(R.string.continuar)) } },
            dismissButton = { TextButton(onClick = { aviso = false }) { Text(stringResource(R.string.cancelar)) } }
        )
    }
    if (ajuda) {
        AlertDialog(
            onDismissRequest = { ajuda = false },
            containerColor = Cartao, titleContentColor = Texto, textContentColor = Mudo,
            title = { Text(stringResource(R.string.ajuda_titulo)) },
            text = { Text(stringResource(R.string.ajuda_texto), modifier = Modifier.verticalScroll(rememberScrollState())) },
            confirmButton = { TextButton(onClick = { ajuda = false }) { Text(stringResource(R.string.ok)) } }
        )
    }

    when {
        rodando -> TelaProcessando(
            progresso, eta, quadro, totalQuadros, e.ampliar, e.gerar
        ) { trabalho?.let { wm.cancelWorkById(it) } }

        concluido -> TelaConcluido(
            info?.outputData?.getString("nome") ?: "",
            info?.outputData?.getString("uri"),
            infoVideo, saidaTxt
        ) {
            e.trabalhoTexto = null; e.uriTexto = null; e.tela = "home"
        }

        e.tela == "ajustes" -> TelaAjustes { e.tela = "home" }

        e.tela == "config" -> TelaConfigurar(
            e, infoVideo, saidaTxt, suporte, codecIdxEf, fsrAtivo, falhou,
            alturas, fpsLista,
            aoVoltar = { e.tela = "home" }, aoAjuda = { ajuda = true }, aoIniciar = { aviso = true }
        )

        else -> TelaHome(
            infoVideo, e.uriTexto != null,
            aoEscolher = abrirSeletor, aoContinuar = { e.tela = "config" }, aoAjustes = { e.tela = "ajustes" }
        )
    }
}

private val ModPagina get() = Modifier.fillMaxSize().systemBarsPadding().padding(20.dp)

@Composable
fun TelaHome(info: InfoVideo?, escolhido: Boolean, aoEscolher: () -> Unit, aoContinuar: () -> Unit, aoAjustes: () -> Unit) {
    Column(ModPagina, verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.app_name), fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.home_sub), color = Mudo)
            }
            TextButton(onClick = aoAjustes) { Text(stringResource(R.string.configuracoes)) }
        }
        Surface(color = Cartao, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(12.dp)).background(Linha)) {
                    info?.miniatura?.let {
                        Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    }
                }
                Text(
                    info?.nome ?: stringResource(if (escolhido) R.string.lendo_video else R.string.nenhum_video),
                    fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (info != null) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Quadro(stringResource(R.string.modo_resolucao), "${info.largura}×${info.altura}", Modifier.weight(1f))
                Quadro("FPS", info.fps, Modifier.weight(1f))
                Quadro(stringResource(R.string.duracao), info.duracao, Modifier.weight(1f))
            }
        }
        Text(stringResource(R.string.home_dica), color = Mudo, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.weight(1f))
        if (!escolhido) {
            Button(onClick = aoEscolher, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text(stringResource(R.string.escolher_video), fontWeight = FontWeight.Bold)
            }
        } else {
            OutlinedButton(onClick = aoEscolher, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text(stringResource(R.string.trocar_video))
            }
            Button(onClick = aoContinuar, enabled = info != null, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text(stringResource(R.string.continuar), fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun Quadro(titulo: String, valor: String, modifier: Modifier = Modifier) {
    Surface(color = Cartao, shape = RoundedCornerShape(12.dp), modifier = modifier.border(1.dp, Linha, RoundedCornerShape(12.dp))) {
        Column(Modifier.padding(12.dp)) {
            Text(titulo, color = Mudo, style = MaterialTheme.typography.labelSmall)
            Text(valor, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
fun TelaConfigurar(
    e: Escolhas, info: InfoVideo?, saidaTxt: String, suporte: List<Boolean>,
    codecIdxEf: Int, fsrAtivo: Boolean, falhou: Boolean,
    alturas: List<Int>, fpsLista: List<Int>,
    aoVoltar: () -> Unit, aoAjuda: () -> Unit, aoIniciar: () -> Unit
) {
    Column(ModPagina, verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = aoVoltar) { Text("←", fontSize = 22.sp) }
            Text(stringResource(R.string.config_titulo), fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Surface(color = Cartao, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)).background(Linha)) {
                    info?.miniatura?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                }
                Column(Modifier.weight(1f)) {
                    Text(info?.nome ?: "", fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (info != null) Text("${info.largura}×${info.altura} · ${info.fps} FPS · ${info.duracao}", color = Mudo, style = MaterialTheme.typography.bodySmall)
                    Text(stringResource(R.string.saida_fmt, saidaTxt), color = Acento, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Rotulo(stringResource(R.string.o_que_melhorar))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Pelo menos um dos dois fica sempre ligado
                Modo(stringResource(R.string.modo_resolucao), e.ampliar, !e.ampliar || e.gerar, Modifier.weight(1f)) { e.ampliar = !e.ampliar }
                Modo(stringResource(R.string.modo_quadros), e.gerar, !e.gerar || e.ampliar, Modifier.weight(1f)) { e.gerar = !e.gerar }
            }
            if (e.ampliar) {
                Rotulo(stringResource(R.string.resolucao_saida))
                Opcao(alturas.map { "${it}p" }, e.alturaIdx, true) { e.alturaIdx = it }
                RotuloAjuda(stringResource(R.string.metodo_ampliacao), aoAjuda)
                Opcao(
                    listOf(R.string.amp_lanczos, R.string.amp_fsr, R.string.amp_vizinho, R.string.amp_anime).map { stringResource(it) },
                    e.ampIdx, true
                ) { e.ampIdx = it }
                when (e.ampIdx) {
                    0 -> {
                        Rotulo(stringResource(R.string.nit_titulo))
                        Opcao(listOf(R.string.nit_unsharp, R.string.nit_cas, R.string.nit_nenhuma).map { stringResource(it) }, e.nitIdx, true) { e.nitIdx = it }
                    }
                    1 -> {
                        Rotulo(stringResource(R.string.rcas_titulo))
                        Opcao(
                            listOf(R.string.rcas_desligada, R.string.rcas_leve, R.string.rcas_media, R.string.rcas_forte).map { stringResource(it) },
                            e.rcasIdx, true
                        ) { e.rcasIdx = it }
                    }
                    3 -> {
                        Rotulo(stringResource(R.string.anime_modo))
                        Opcao(listOf("A · 1080p", "B · 720p", "C · 480p", stringResource(R.string.anime_modo_3d)), e.animeModoIdx, true) { e.animeModoIdx = it }
                        Rotulo(stringResource(R.string.anime_qualidade))
                        Opcao(listOf(R.string.anime_rapida, R.string.anime_alta).map { stringResource(it) }, e.animeQualIdx, e.animeModoIdx != 3) { e.animeQualIdx = it }
                        Rotulo(stringResource(R.string.rcas_titulo))
                        Opcao(
                            listOf(R.string.rcas_desligada, R.string.rcas_leve, R.string.rcas_media, R.string.rcas_forte).map { stringResource(it) },
                            e.rcasIdx, true
                        ) { e.rcasIdx = it }
                        Text(stringResource(R.string.anime_aviso), color = Acento, style = MaterialTheme.typography.bodySmall)
                    }
                    else -> Text(stringResource(R.string.info_vizinho), color = Mudo)
                }
            }
            if (e.gerar) {
                Rotulo(stringResource(R.string.fps_saida))
                Opcao(fpsLista.map { "$it" }, e.fpsIdx, true) { e.fpsIdx = it }
                RotuloAjuda(stringResource(R.string.metodo_quadros), aoAjuda)
                Opcao(listOf(R.string.qua_blend, R.string.qua_framerate, R.string.qua_movimento).map { stringResource(it) }, e.quaIdx, true) { e.quaIdx = it }
                when (e.quaIdx) {
                    0 -> Text(stringResource(R.string.info_blend), color = Mudo)
                    1 -> Text(stringResource(R.string.info_framerate), color = Mudo)
                    else -> {
                        Rotulo(stringResource(R.string.nivel_titulo))
                        Opcao(
                            listOf(R.string.nivel_rapido, R.string.nivel_equilibrado, R.string.nivel_qualidade, R.string.nivel_2d).map { stringResource(it) },
                            e.nivelIdx, true
                        ) { e.nivelIdx = it }
                    }
                }
            }
            Text(stringResource(R.string.realce_titulo), fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Rotulo(stringResource(R.string.limpeza_titulo))
            Opcao(
                listOf(R.string.rcas_desligada, R.string.rcas_leve, R.string.rcas_media, R.string.rcas_forte).map { stringResource(it) },
                e.limpezaIdx, true
            ) { e.limpezaIdx = it }
            Rotulo(stringResource(R.string.ruido_titulo))
            Opcao(
                listOf(R.string.desligado, R.string.ruido_media, R.string.ruido_mediana, R.string.ruido_moda).map { stringResource(it) },
                e.ruidoIdx, true
            ) { e.ruidoIdx = it }
            Rotulo(stringResource(R.string.deblur_titulo))
            Opcao(
                listOf(R.string.desligado, R.string.deblur_dog, R.string.deblur_original).map { stringResource(it) },
                e.deblurIdx, true
            ) { e.deblurIdx = it }
            if (realceAtivo) {
                Rotulo(stringResource(R.string.quando_titulo))
                Opcao(
                    listOf(R.string.quando_antes, R.string.quando_depois, R.string.quando_ambos).map { stringResource(it) },
                    if (escalaGpu) e.quandoIdx else 1, true,
                    if (escalaGpu) emptySet() else setOf(0, 2)
                ) { e.quandoIdx = it }
            }
            Text(stringResource(R.string.realce_dica), color = Mudo, style = MaterialTheme.typography.bodySmall)
            Rotulo(stringResource(R.string.codec_titulo))
            Opcao(
                listOf(R.string.codec_h264, R.string.codec_h265, R.string.codec_av1).map { stringResource(it) },
                codecIdxEf, true,
                setOf(0, 1, 2).filter { !suporte[it] || (it == 2 && fsrAtivo) }.toSet()
            ) { e.codecIdx = it }
            Text(stringResource(R.string.codec_dica), color = Mudo, style = MaterialTheme.typography.bodySmall)
            if (fsrAtivo) Text(stringResource(R.string.fsr_aviso), color = Acento, style = MaterialTheme.typography.bodySmall)
        }
        if (falhou) Text(stringResource(R.string.falhou), color = Color(0xFFFF8A80))
        Button(onClick = aoIniciar, modifier = Modifier.fillMaxWidth().height(52.dp)) {
            Text(stringResource(R.string.iniciar), fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun TelaProcessando(
    progresso: Int, eta: Int, quadro: Int, total: Int,
    ampliar: Boolean, gerar: Boolean, aoCancelar: () -> Unit
) {
    val ctx = LocalContext.current
    Column(ModPagina, verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Column {
            Text(stringResource(R.string.processando_titulo), fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(stringResource(R.string.processando_sub), color = Mudo)
        }
        Surface(color = Cartao, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("$progresso%", fontSize = 44.sp, fontWeight = FontWeight.Bold)
                Text(Idioma.etaTexto(ctx, eta), color = Acento, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
                if (total > 0) {
                    Text(stringResource(R.string.quadro_fmt, quadro, total), color = Mudo, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 2.dp))
                }
                LinearProgressIndicator(progress = { progresso / 100f }, modifier = Modifier.fillMaxWidth().padding(top = 14.dp))
            }
        }
        Surface(color = Cartao, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (ampliar) Etapa(stringResource(R.string.etapa_resolucao), stringResource(R.string.est_andamento), Acento)
                if (gerar) Etapa(stringResource(R.string.etapa_quadros), stringResource(R.string.est_andamento), Acento)
                Etapa(stringResource(R.string.etapa_galeria), stringResource(R.string.est_aguardando), Mudo)
            }
        }
        Spacer(Modifier.weight(1f))
        OutlinedButton(onClick = aoCancelar, modifier = Modifier.fillMaxWidth().height(52.dp)) {
            Text(stringResource(R.string.cancelar), fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun Etapa(nome: String, estado: String, cor: Color) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(nome)
        Text(estado, color = cor, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun TelaConcluido(nome: String, uriSaida: String?, info: InfoVideo?, saidaTxt: String, aoOutro: () -> Unit) {
    val ctx = LocalContext.current
    Column(ModPagina, verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Column {
            Text(stringResource(R.string.concluido_titulo), fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(stringResource(R.string.concluido_sub), color = Mudo)
        }
        Surface(color = Cartao, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(72.dp).clip(RoundedCornerShape(12.dp)).background(Linha)) {
                    info?.miniatura?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                }
                Column {
                    Text(nome, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(stringResource(R.string.pasta_fmt), color = Mudo, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Quadro(stringResource(R.string.antes), if (info != null) "${info.altura}p · ${info.fps} FPS" else "—", Modifier.weight(1f))
            Quadro(stringResource(R.string.depois), saidaTxt, Modifier.weight(1f))
        }
        Spacer(Modifier.weight(1f))
        val uri = uriSaida?.let { Uri.parse(it) }
        Button(
            onClick = {
                uri?.let {
                    runCatching {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(it, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                    }
                }
            },
            enabled = uri != null, modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text(stringResource(R.string.abrir_galeria), fontWeight = FontWeight.Bold) }
        OutlinedButton(
            onClick = {
                uri?.let {
                    runCatching {
                        val i = Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, it)
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        ctx.startActivity(Intent.createChooser(i, null))
                    }
                }
            },
            enabled = uri != null, modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text(stringResource(R.string.compartilhar)) }
        OutlinedButton(onClick = aoOutro, modifier = Modifier.fillMaxWidth().height(52.dp)) {
            Text(stringResource(R.string.outro_video))
        }
    }
}

@Composable
fun TelaAjustes(aoVoltar: () -> Unit) {
    val ctx = LocalContext.current
    val atual = remember { Idioma.salvo(ctx) }
    Column(ModPagina, verticalArrangement = Arrangement.spacedBy(16.dp)) {
        TextButton(onClick = aoVoltar) { Text("←  " + stringResource(R.string.voltar)) }
        Text(stringResource(R.string.configuracoes), fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Rotulo(stringResource(R.string.idioma))
        Opcao(
            listOf(stringResource(R.string.idioma_pt), stringResource(R.string.idioma_en)),
            if (atual == "pt") 0 else 1, true
        ) { i ->
            Idioma.salvar(ctx, if (i == 0) "pt" else "en")
            ctx.ativ()?.recreate()
        }
        Rotulo(stringResource(R.string.sobre))
        Surface(color = Cartao, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(72.dp).clip(RoundedCornerShape(18.dp)).background(Fundo).border(1.dp, Linha, RoundedCornerShape(18.dp))) {
                    Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.fillMaxSize())
                }
                Column {
                    Text(stringResource(R.string.app_name), fontWeight = FontWeight.SemiBold)
                    Text(stringResource(R.string.sobre_versao), color = Mudo, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun Rotulo(texto: String) = Text(texto, color = Mudo, fontWeight = FontWeight.SemiBold)

@Composable
fun RotuloAjuda(texto: String, aoAjuda: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Rotulo(texto)
        TextButton(onClick = aoAjuda) { Text(stringResource(R.string.como_funciona)) }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Opcao(
    titulos: List<String>, sel: Int, ativo: Boolean,
    desabilitados: Set<Int> = emptySet(), aoEscolher: (Int) -> Unit
) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        titulos.forEachIndexed { i, t ->
            FilterChip(selected = i == sel, onClick = { aoEscolher(i) }, label = { Text(t) }, enabled = ativo && i !in desabilitados)
        }
    }
}

@Composable
fun Modo(texto: String, ativo: Boolean, habilitado: Boolean, modifier: Modifier, aoClicar: () -> Unit) {
    if (ativo) Button(onClick = aoClicar, enabled = habilitado, modifier = modifier.height(48.dp)) { Text(texto) }
    else OutlinedButton(onClick = aoClicar, enabled = habilitado, modifier = modifier.height(48.dp)) { Text(texto) }
}
