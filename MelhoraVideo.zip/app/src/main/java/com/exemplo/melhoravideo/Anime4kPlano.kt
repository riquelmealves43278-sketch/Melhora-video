package com.exemplo.melhoravideo

/** Modos do Anime4K v4: A (anime 1080p), B (720p), C (480p) e D3 (gráficos 3D, ultra leve, experimental). */
enum class Anime4kModo { A, B, C, D3 }

/** RAPIDA = variantes M/S; ALTA = variantes VL (bem mais pesadas). */
enum class Anime4kQualidade { RAPIDA, ALTA }

/** Um passe de um shader no formato "hook" do mpv. */
class Passo(
    val desc: String,
    val hook: String,
    val binds: List<String>,
    val salvar: String?,
    val largura: String?,
    val altura: String?,
    val quando: String?,
    val codigo: String
)

/** Lógica pura (sem Android) para ler e montar os shaders do Anime4K (licença MIT, bloc97). */
object Anime4kPlano {

    /** Sequência oficial de arquivos de cada modo (mesma do README do Anime4K). */
    fun arquivos(modo: Anime4kModo, qualidade: Anime4kQualidade): List<String> {
        val rapida = qualidade == Anime4kQualidade.RAPIDA
        val grande = if (rapida) "M" else "VL"
        val pequeno = if (rapida || modo == Anime4kModo.D3) "S" else "M"
        val nomes = mutableListOf("Clamp_Highlights")
        when (modo) {
            Anime4kModo.A -> nomes += listOf("Restore_CNN_$grande", "Upscale_CNN_x2_$grande")
            Anime4kModo.B -> nomes += listOf("Restore_CNN_Soft_$grande", "Upscale_CNN_x2_$grande")
            Anime4kModo.C -> nomes += listOf("Upscale_Denoise_CNN_x2_$grande")
            Anime4kModo.D3 -> nomes += listOf("3DGraphics_AA_Upscale_x2_US")
        }
        nomes += listOf("AutoDownscalePre_x2", "AutoDownscalePre_x4", "Upscale_CNN_x2_$pequeno")
        return nomes.map { "anime4k/Anime4K_$it.glsl" }
    }

    /** Shaders de realce (rodam em qualquer método): primeiro reduz o ruído, depois o deblur. */
    fun arquivosRealce(ruido: RuidoGpu, deblur: DeblurGpu): List<String> {
        val nomes = mutableListOf<String>()
        when (ruido) {
            RuidoGpu.MEDIA -> nomes += "Denoise_Bilateral_Mean"
            RuidoGpu.MEDIANA -> nomes += "Denoise_Bilateral_Median"
            RuidoGpu.MODA -> nomes += "Denoise_Bilateral_Mode"
            RuidoGpu.DESLIGADO -> Unit
        }
        when (deblur) {
            DeblurGpu.DOG -> nomes += "Deblur_DoG"
            DeblurGpu.ORIGINAL -> nomes += "Deblur_Original"
            DeblurGpu.DESLIGADO -> Unit
        }
        return nomes.map { "anime4k/Anime4K_$it.glsl" }
    }

    /** Separa o arquivo em passes (cada passe começa por linhas //!DIRETIVA e tem o código logo depois). */
    fun analisar(texto: String): List<Passo> {
        val passos = mutableListOf<Passo>()
        var cab = LinkedHashMap<String, MutableList<String>>()
        val codigo = StringBuilder()
        var temCodigo = false

        fun fechar() {
            val hook = cab["HOOK"]?.firstOrNull()
            if (hook != null) {
                passos += Passo(
                    desc = cab["DESC"]?.firstOrNull() ?: "",
                    hook = hook,
                    binds = cab["BIND"] ?: emptyList(),
                    salvar = cab["SAVE"]?.firstOrNull(),
                    largura = cab["WIDTH"]?.firstOrNull(),
                    altura = cab["HEIGHT"]?.firstOrNull(),
                    quando = cab["WHEN"]?.firstOrNull(),
                    codigo = codigo.toString()
                )
            }
            cab = LinkedHashMap()
            codigo.clear()
            temCodigo = false
        }

        for (linha in texto.lines()) {
            val t = linha.trim()
            if (t.startsWith("//!")) {
                if (temCodigo) fechar()
                val resto = t.substring(3)
                val i = resto.indexOf(' ')
                val chave = if (i < 0) resto else resto.substring(0, i)
                val valor = if (i < 0) "" else resto.substring(i + 1).trim()
                cab.getOrPut(chave) { mutableListOf() }.add(valor)
            } else {
                codigo.append(linha).append('\n')
                if (t.isNotEmpty() && !t.startsWith("//")) temCodigo = true
            }
        }
        fechar()
        return passos
    }

    /** Calcula expressões em notação polonesa inversa (WIDTH/HEIGHT/WHEN). Null = nome desconhecido. */
    fun avaliar(expr: String, tamanho: (String) -> Pair<Int, Int>?): Double? {
        val pilha = ArrayList<Double>()
        fun b(v: Boolean) = if (v) 1.0 else 0.0
        for (t in expr.trim().split(Regex("\\s+"))) {
            if (t.isEmpty()) continue
            val num = t.toDoubleOrNull()
            if (num != null) { pilha.add(num); continue }
            if (t.endsWith(".w") || t.endsWith(".h")) {
                val tam = tamanho(t.dropLast(2)) ?: return null
                pilha.add((if (t.endsWith(".w")) tam.first else tam.second).toDouble())
                continue
            }
            if (t == "!") {
                if (pilha.isEmpty()) return null
                pilha.add(b(pilha.removeAt(pilha.size - 1) == 0.0)); continue
            }
            if (pilha.size < 2) return null
            val y = pilha.removeAt(pilha.size - 1)
            val x = pilha.removeAt(pilha.size - 1)
            pilha.add(
                when (t) {
                    "+" -> x + y
                    "-" -> x - y
                    "*" -> x * y
                    "/" -> x / y
                    "%" -> x % y
                    ">" -> b(x > y)
                    "<" -> b(x < y)
                    ">=" -> b(x >= y)
                    "<=" -> b(x <= y)
                    "==" -> b(x == y)
                    "&&" -> b(x != 0.0 && y != 0.0)
                    "||" -> b(x != 0.0 || y != 0.0)
                    else -> return null
                }
            )
        }
        return pilha.singleOrNull()
    }

    /** Monta o fragment shader (GLSL ES 3.1): define as "macros" do mpv para cada textura ligada. */
    fun montarShader(p: Passo): String {
        val sb = StringBuilder()
        sb.append("#version 310 es\nprecision highp float;\nprecision highp int;\nprecision highp sampler2D;\n")
        sb.append("in vec2 uv;\nout vec4 fragColor;\n")
        for (n in p.binds.distinct()) {
            sb.append("uniform sampler2D A4K_tex_$n;\nuniform vec2 A4K_size_$n;\n")
            sb.append("#define ${n}_pos uv\n")
            sb.append("#define ${n}_size A4K_size_$n\n")
            sb.append("#define ${n}_pt (vec2(1.0) / A4K_size_$n)\n")
            sb.append("#define ${n}_tex(p) texture(A4K_tex_$n, p)\n")
            sb.append("#define ${n}_texOff(o) texture(A4K_tex_$n, uv + (o) * (vec2(1.0) / A4K_size_$n))\n")
        }
        // No mpv, HOOKED também responde pelo nome do ponto de gancho (ex.: MAIN)
        if ("HOOKED" in p.binds && p.hook !in p.binds) {
            val n = p.hook
            sb.append("#define ${n}_pos uv\n")
            sb.append("#define ${n}_size A4K_size_HOOKED\n")
            sb.append("#define ${n}_pt (vec2(1.0) / A4K_size_HOOKED)\n")
            sb.append("#define ${n}_tex(p) texture(A4K_tex_HOOKED, p)\n")
            sb.append("#define ${n}_texOff(o) texture(A4K_tex_HOOKED, uv + (o) * (vec2(1.0) / A4K_size_HOOKED))\n")
        }
        sb.append(p.codigo)
        sb.append("\nvoid main() { fragColor = hook(); }\n")
        return sb.toString()
    }
}
