package com.exemplo.melhoravideo

/** Como a resolução é ampliada (sempre Lanczos; muda só o passo de nitidez). */
enum class MetodoAmpliacao { LANCZOS_NITIDEZ, LANCZOS_CAS, LANCZOS }

/** Como os quadros novos são gerados. */
enum class MetodoQuadros { RAPIDO, QUALIDADE }

data class Opcoes(
    val altura: Int,                 // lado menor de saída: 720, 1080, 1440, 2160
    val fps: Int,                    // 30, 60, 90, 120
    val ampliar: Boolean,            // modo "Resolução"
    val gerarQuadros: Boolean,       // modo "Gerar quadros"
    val metodoAmpliacao: MetodoAmpliacao = MetodoAmpliacao.LANCZOS_NITIDEZ,
    val metodoQuadros: MetodoQuadros = MetodoQuadros.QUALIDADE
)

/** Divisão em blocos do AV1: mais blocos = mais núcleos trabalhando ao mesmo tempo. */
private fun ladrilhos(nucleos: Int) = when {
    nucleos >= 8 -> "4x2"
    nucleos >= 4 -> "2x2"
    else -> "2x1"
}

/**
 * Escala mantendo a proporção, com largura/altura sempre pares.
 * Vídeos ~16:9 (ex.: 854x480) viram exatamente 1920x1080 (ou 1280x720 etc.).
 * Em vídeos em pé, o valor escolhido vale para o lado menor (a largura).
 */
private fun escala(a: Int): String {
    val w = "trunc(if(gte(a,1),if(lt(abs(a-16/9),0.02),$a*16/9,$a*a),$a)/2)*2"
    val h = "trunc(if(gte(a,1),$a,if(lt(abs(1/a-16/9),0.02),$a*16/9,$a/a))/2)*2"
    return "scale=w='$w':h='$h':flags=lanczos"
}

/** Monta os argumentos do FFmpeg. Cada método é só um filtro, fácil de adicionar outros. */
fun montarArgumentos(
    entrada: String,
    saida: String,
    o: Opcoes,
    nucleos: Int = Runtime.getRuntime().availableProcessors()
): Array<String> {
    val filtros = buildList {
        // Interpolar antes de ampliar: trabalha em resolução menor (mais rápido)
        if (o.gerarQuadros) {
            add(
                when (o.metodoQuadros) {
                    MetodoQuadros.RAPIDO -> "minterpolate=fps=${o.fps}:mi_mode=blend"
                    MetodoQuadros.QUALIDADE -> "minterpolate=fps=${o.fps}"
                }
            )
        }
        if (o.ampliar) {
            add(escala(o.altura))
            when (o.metodoAmpliacao) {
                MetodoAmpliacao.LANCZOS_NITIDEZ -> add("unsharp=5:5:0.8:5:5:0.0")
                MetodoAmpliacao.LANCZOS_CAS -> add("cas=0.6")
                MetodoAmpliacao.LANCZOS -> Unit
            }
        }
    }
    return buildList {
        addAll(listOf("-y", "-i", entrada))
        if (filtros.isNotEmpty()) addAll(listOf("-vf", filtros.joinToString(",")))
        addAll(listOf(
            "-c:v", "libaom-av1", "-crf", "32", "-b:v", "0",
            "-cpu-used", "8", "-row-mt", "1",
            "-threads", "$nucleos", "-tiles", ladrilhos(nucleos),
            "-pix_fmt", "yuv420p",
            "-c:a", "copy",
            "-movflags", "+faststart",
            saida
        ))
    }.toTypedArray()
}
