package com.exemplo.melhoravideo

import kotlin.math.abs
import kotlin.math.floor

enum class Codec { H264, H265, AV1 }
enum class MetodoAmpliacao { LANCZOS, FSR, VIZINHO, ANIME4K }
enum class Nitidez { UNSHARP, CAS, NENHUMA }
enum class Rcas { DESLIGADA, LEVE, MEDIA, FORTE }
enum class MetodoQuadros { BLEND, FRAMERATE, MOVIMENTO }
enum class NivelMovimento { RAPIDO, EQUILIBRADO, QUALIDADE, JOGO_2D }
enum class Limpeza { DESLIGADA, LEVE, MEDIA, FORTE }              // filtro temporal do FFmpeg (hqdn3d)
enum class RuidoGpu { DESLIGADO, MEDIA, MEDIANA, MODA }           // Anime4K Denoise Bilateral (GPU)
enum class DeblurGpu { DESLIGADO, DOG, ORIGINAL }                 // Anime4K Deblur (GPU)
enum class QuandoRealce { ANTES, DEPOIS, AMBOS }                  // em relação à ampliação

data class Opcoes(
    val altura: Int,                 // lado menor de saída: 720, 1080, 1440, 2160
    val fps: Int,                    // 30, 60, 90, 120
    val ampliar: Boolean,            // modo "Resolução"
    val gerarQuadros: Boolean,       // modo "Gerar quadros"
    val codec: Codec = Codec.H264,
    val metodoAmpliacao: MetodoAmpliacao = MetodoAmpliacao.LANCZOS,
    val nitidez: Nitidez = Nitidez.UNSHARP,
    val rcas: Rcas = Rcas.LEVE,
    val metodoQuadros: MetodoQuadros = MetodoQuadros.MOVIMENTO,
    val nivel: NivelMovimento = NivelMovimento.EQUILIBRADO,
    val anime4kModo: Anime4kModo = Anime4kModo.A,
    val anime4kQualidade: Anime4kQualidade = Anime4kQualidade.RAPIDA,
    val limpeza: Limpeza = Limpeza.DESLIGADA,
    val ruidoGpu: RuidoGpu = RuidoGpu.DESLIGADO,
    val deblur: DeblurGpu = DeblurGpu.DESLIGADO,
    val quando: QuandoRealce = QuandoRealce.DEPOIS
)

fun realceGpuAtivo(o: Opcoes) = o.ruidoGpu != RuidoGpu.DESLIGADO || o.deblur != DeblurGpu.DESLIGADO

/** Limpeza usando os quadros vizinhos (barata). Vai no começo da cadeia de filtros. */
private fun filtroLimpeza(l: Limpeza): String? = when (l) {
    Limpeza.DESLIGADA -> null
    Limpeza.LEVE -> "hqdn3d=1:1:3:3"
    Limpeza.MEDIA -> "hqdn3d=2:2:5:5"
    Limpeza.FORTE -> "hqdn3d=4:3:8:6"
}

/** "Stops" do RCAS do FSR: 0 = mais nítido; quanto maior, menos nitidez. Null = sem RCAS. */
fun stopsRcas(r: Rcas): Float? = when (r) {
    Rcas.DESLIGADA -> null
    Rcas.LEVE -> 1.0f
    Rcas.MEDIA -> 0.5f
    Rcas.FORTE -> 0.25f
}

/** Filtro que cria os quadros novos. */
private fun filtroQuadros(o: Opcoes): String = when (o.metodoQuadros) {
    MetodoQuadros.BLEND -> "minterpolate=fps=${o.fps}:mi_mode=blend"
    MetodoQuadros.FRAMERATE -> "framerate=fps=${o.fps}"
    MetodoQuadros.MOVIMENTO -> when (o.nivel) {
        NivelMovimento.RAPIDO -> "minterpolate=fps=${o.fps}:mc_mode=obmc:me_mode=bilat:mb_size=16:search_param=16"
        NivelMovimento.EQUILIBRADO -> "minterpolate=fps=${o.fps}"
        NivelMovimento.QUALIDADE -> "minterpolate=fps=${o.fps}:mc_mode=aobmc:vsbmc=1"
        NivelMovimento.JOGO_2D -> "minterpolate=fps=${o.fps}:mc_mode=aobmc:vsbmc=1:mb_size=8:search_param=48"
    }
}

private fun filtroNitidez(n: Nitidez): String? = when (n) {
    Nitidez.UNSHARP -> "unsharp=5:5:0.8:5:5:0.0"
    Nitidez.CAS -> "cas=0.6"
    Nitidez.NENHUMA -> null
}

/** Tamanho final mantendo a proporção, sempre par. ~16:9 vira exatamente 1920x1080 etc. Em pé: o valor vale para a largura. */
fun tamanhoSaida(w: Int, h: Int, altura: Int): Pair<Int, Int> {
    val a = w.toDouble() / h
    fun par(v: Double) = (floor(v / 2.0) * 2).toInt()
    return if (a >= 1.0) {
        val ow = if (abs(a - 16.0 / 9.0) < 0.02) altura * 16.0 / 9.0 else altura * a
        par(ow) to altura
    } else {
        val oh = if (abs(1.0 / a - 16.0 / 9.0) < 0.02) altura * 16.0 / 9.0 else altura / a
        altura to par(oh)
    }
}

/** Escala para o caminho AV1 (o FFmpeg calcula o tamanho sozinho). */
private fun escalaAv1(a: Int, flags: String): String {
    val w = "trunc(if(gte(a,1),if(lt(abs(a-16/9),0.02),$a*16/9,$a*a),$a)/2)*2"
    val h = "trunc(if(gte(a,1),$a,if(lt(abs(1/a-16/9),0.02),$a*16/9,$a/a))/2)*2"
    return "scale=w='$w':h='$h':flags=$flags"
}

/** Divisão em blocos do AV1: mais blocos = mais núcleos trabalhando ao mesmo tempo. */
private fun ladrilhos(nucleos: Int) = when {
    nucleos >= 8 -> "4x2"
    nucleos >= 4 -> "2x2"
    else -> "2x1"
}

/** Caminho AV1 (software, libaom): o FFmpeg faz tudo e grava o MP4. FSR não existe aqui (vira Lanczos). */
fun montarArgumentos(
    entrada: String,
    saida: String,
    o: Opcoes,
    nucleos: Int = Runtime.getRuntime().availableProcessors()
): Array<String> {
    val filtros = buildList {
        filtroLimpeza(o.limpeza)?.let { add(it) }
        if (o.gerarQuadros) add(filtroQuadros(o))
        if (o.ampliar) {
            if (o.metodoAmpliacao == MetodoAmpliacao.VIZINHO) {
                add(escalaAv1(o.altura, "neighbor"))
            } else {
                add(escalaAv1(o.altura, "lanczos"))
                filtroNitidez(o.nitidez)?.let { add(it) }
            }
        }
    }
    return buildList {
        addAll(listOf("-y", "-i", entrada))
        if (filtros.isNotEmpty()) addAll(listOf("-vf", filtros.joinToString(",")))
        addAll(listOf(
            "-c:v", "libaom-av1", "-crf", "32", "-b:v", "0",
            "-cpu-used", "8", "-row-mt", "1",
            "-threads", "$nucleos", "-tiles", ladrilhos(nucleos),
            "-pix_fmt", "yuv420p",
            "-c:a", "copy",
            "-movflags", "+faststart",
            saida
        ))
    }.toTypedArray()
}

/**
 * Caminho MediaCodec/GPU: o FFmpeg aplica o que é de CPU (quadros, Lanczos...) e manda quadros brutos
 * (yuv420p) pelo pipe. O app faz o FSR na GPU (se pedido) e o codificador do celular grava o vídeo.
 * frameW/H = tamanho dos quadros que saem do FFmpeg.
 */
fun argumentosBruto(
    entrada: String,
    pipe: String,
    o: Opcoes,
    srcW: Int, srcH: Int,
    outW: Int, outH: Int,
    gpuAmplia: Boolean,
    fpsOriginal: String
): Array<String> {
    val filtros = buildList {
        filtroLimpeza(o.limpeza)?.let { add(it) }
        if (o.gerarQuadros) add(filtroQuadros(o)) else add("fps=$fpsOriginal")
        if (o.ampliar && !gpuAmplia) {
            if (o.metodoAmpliacao == MetodoAmpliacao.VIZINHO) {
                add("scale=$outW:$outH:flags=neighbor")
            } else {
                add("scale=$outW:$outH:flags=lanczos")
                filtroNitidez(o.nitidez)?.let { add(it) }
            }
        } else {
            add("scale=$srcW:$srcH")   // só garante tamanho par
        }
        add("format=yuv420p")
    }
    return arrayOf(
        "-y", "-i", entrada, "-an",
        "-vf", filtros.joinToString(","),
        "-f", "rawvideo", "-pix_fmt", "yuv420p", pipe
    )
}

fun bitrateAlvo(w: Int, h: Int, fps: Double, h265: Boolean): Int {
    val bitsPorPixel = if (h265) 0.08 else 0.12
    return (w * h * fps * bitsPorPixel).toLong().coerceIn(2_000_000L, 80_000_000L).toInt()
}

fun fpsDeTexto(r: String?): Double {
    val p = r?.split("/") ?: return 0.0
    val n = p.getOrNull(0)?.toDoubleOrNull() ?: return 0.0
    val d = p.getOrNull(1)?.toDoubleOrNull() ?: 1.0
    return if (d == 0.0) 0.0 else n / d
}

/** Calcula % concluído e tempo restante (suavizado). */
class Estimador(private val duracaoMs: Double) {
    private val inicio = System.currentTimeMillis()
    private var etaSuave = -1.0
    private var ultimoP = -1

    /** Devolve (percentual, segundos restantes ou -1) quando o percentual muda; senão null. */
    fun atualizar(feitoMs: Double): Pair<Int, Int>? {
        if (duracaoMs <= 0) return null
        val p = (feitoMs / duracaoMs * 100).toInt().coerceIn(0, 99)
        if (p == ultimoP) return null
        ultimoP = p
        val decorrido = System.currentTimeMillis() - inicio
        var eta = -1
        if (feitoMs > 0 && decorrido > 5000) {
            val bruto = (duracaoMs - feitoMs) * decorrido / feitoMs / 1000.0
            etaSuave = if (etaSuave < 0) bruto else etaSuave * 0.8 + bruto * 0.2
            eta = etaSuave.toInt()
        }
        return p to eta
    }
}
