package com.exemplo.melhoravideo

/** Shaders pequenos do app (FSR 1.0 e Anime4K ficam em assets). */
object GpuShaders {
    const val VERTICE = """#version 310 es
out vec2 uv;
void main() {
    vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
    uv = p;
    gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}
"""

    const val YUV_PARA_RGB = """#version 310 es
precision highp float;
uniform sampler2D ty;
uniform sampler2D tu;
uniform sampler2D tv;
in vec2 uv;
out vec4 fragColor;
void main() {
    float y = (texture(ty, uv).r - 16.0 / 255.0) * (255.0 / 219.0);
    float u = (texture(tu, uv).r - 0.5) * (255.0 / 224.0);
    float v = (texture(tv, uv).r - 0.5) * (255.0 / 224.0);
    vec3 rgb = vec3(y + 1.5748 * v, y - 0.1873 * u - 0.4681 * v, y + 1.8556 * u);
    fragColor = vec4(clamp(rgb, 0.0, 1.0), 1.0);
}
"""

    const val COPIA_INVERTIDA = """#version 310 es
precision highp float;
precision highp int;
precision highp sampler2D;
uniform sampler2D tex;
in vec2 uv;
out vec4 fragColor;
void main() {
    fragColor = vec4(texture(tex, vec2(uv.x, 1.0 - uv.y)).rgb, 1.0);
}
"""

    const val REDIMENSIONA_LANCZOS = """#version 310 es
precision highp float;
precision highp int;
precision highp sampler2D;
uniform sampler2D tex;
uniform vec2 uIn;
uniform vec2 uOut;
in vec2 uv;
out vec4 fragColor;
const float A = 2.0;
float lz(float x) {
    x = abs(x);
    if (x < 1e-4) return 1.0;
    if (x >= A) return 0.0;
    float px = 3.14159265 * x;
    return A * sin(px) * sin(px / A) / (px * px);
}
void main() {
    vec2 f = max(uIn / uOut, vec2(1.0));
    vec2 c = uv * uIn - 0.5;
    ivec2 base = ivec2(floor(c));
    ivec2 r = ivec2(ceil(A * f));
    ivec2 maxp = ivec2(uIn) - 1;
    vec3 acc = vec3(0.0);
    float soma = 0.0;
    for (int j = 1 - r.y; j <= r.y; j++) {
        float wy = lz((float(base.y + j) - c.y) / f.y);
        for (int i = 1 - r.x; i <= r.x; i++) {
            float w = wy * lz((float(base.x + i) - c.x) / f.x);
            ivec2 p = clamp(base + ivec2(i, j), ivec2(0), maxp);
            acc += w * texelFetch(tex, p, 0).rgb;
            soma += w;
        }
    }
    fragColor = vec4(clamp(acc / soma, 0.0, 1.0), 1.0);
}
"""
}
