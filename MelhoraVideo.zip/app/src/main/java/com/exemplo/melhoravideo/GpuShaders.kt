package com.exemplo.melhoravideo

/** Shaders pequenos do app (os do FSR 1.0 ficam em assets/shaders). */
object GpuShaders {
    const val VERTICE = """#version 310 es
out vec2 uv;
void main() {
    vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
    uv = p;
    gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}
"""

    const val YUV_PARA_RGB = """#version 310 es
precision highp float;
uniform sampler2D ty;
uniform sampler2D tu;
uniform sampler2D tv;
in vec2 uv;
out vec4 fragColor;
void main() {
    vec2 t = vec2(uv.x, 1.0 - uv.y);
    float y = (texture(ty, t).r - 16.0 / 255.0) * (255.0 / 219.0);
    float u = (texture(tu, t).r - 0.5) * (255.0 / 224.0);
    float v = (texture(tv, t).r - 0.5) * (255.0 / 224.0);
    vec3 rgb = vec3(y + 1.5748 * v, y - 0.1873 * u - 0.4681 * v, y + 1.8556 * u);
    fragColor = vec4(clamp(rgb, 0.0, 1.0), 1.0);
}
"""
}
