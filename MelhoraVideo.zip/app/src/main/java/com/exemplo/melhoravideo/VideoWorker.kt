package com.exemplo.melhoravideo

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentValues
import android.content.Context
import android.content.pm.ServiceInfo
import android.net.Uri
import android.provider.MediaStore
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.work.*
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode
import com.arthenica.ffmpegkit.StreamInformation
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume
import kotlin.math.abs

class VideoWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    private val canal = "processamento"

    private class Midia(
        val duracaoMs: Double, val srcW: Int, val srcH: Int,
        val fpsTexto: String, val fps: Double
    )

    private inline fun <reified E : Enum<E>> enumDe(chave: String, padrao: E): E =
        runCatching { enumValueOf<E>(inputData.getString(chave) ?: "") }.getOrDefault(padrao)

    override suspend fun doWork(): Result {
        val c = applicationContext
        val opcoes = Opcoes(
            altura = inputData.getInt("altura", 1080),
            fps = inputData.getInt("fps", 60),
            ampliar = inputData.getBoolean("ampliar", true),
            gerarQuadros = inputData.getBoolean("gerar", true),
            codec = enumDe("codec", Codec.H264),
            metodoAmpliacao = enumDe("amp", MetodoAmpliacao.LANCZOS),
            nitidez = enumDe("nit", Nitidez.UNSHARP),
            rcas = enumDe("rcas", Rcas.LEVE),
            metodoQuadros = enumDe("qua", MetodoQuadros.MOVIMENTO),
            nivel = enumDe("nivel", NivelMovimento.EQUILIBRADO)
        )
        val entrada = File(c.cacheDir, "entrada.mp4")
        val saida = File(c.cacheDir, "saida.mp4")
        setForeground(info(0, -1))

        try {
            // Copia o vídeo escolhido para o cache (simples e evita problemas de SAF)
            c.contentResolver.openInputStream(Uri.parse(inputData.getString("uri")!!))!!.use { i ->
                entrada.outputStream().use { i.copyTo(it) }
            }
            val midia = sondar(entrada) ?: return Result.failure()
            if (!processar(entrada, saida, opcoes, midia)) return Result.failure()

            salvarNaGaleria(saida)
            setProgress(workDataOf("p" to 100, "eta" to 0))
            return Result.success()
        } catch (e: Cancelado) {
            return Result.failure()
        } finally {
            entrada.delete(); saida.delete()
        }
    }

    private fun rotacao(v: StreamInformation): Int {
        val sd = v.allProperties?.optJSONArray("side_data_list")
        if (sd != null) {
            for (i in 0 until sd.length()) {
                val r = sd.optJSONObject(i)?.optInt("rotation", 0) ?: 0
                if (r != 0) return r
            }
        }
        return v.tags?.optString("rotate")?.toIntOrNull() ?: 0
    }

    private fun sondar(f: File): Midia? {
        val mi = FFprobeKit.getMediaInformation(f.absolutePath).mediaInformation ?: return null
        val v = mi.streams?.firstOrNull { it.type == "video" } ?: return null
        var w = (v.width ?: 0L).toInt()
        var h = (v.height ?: 0L).toInt()
        if (abs(rotacao(v)) % 180 == 90) { val t = w; w = h; h = t }
        if (w <= 0 || h <= 0) return null
        val texto = v.averageFrameRate?.takeIf { fpsDeTexto(it) > 0 } ?: v.realFrameRate ?: "30/1"
        val fps = fpsDeTexto(texto).takeIf { it > 0 } ?: 30.0
        val dur = (mi.duration?.toDoubleOrNull() ?: 0.0) * 1000
        return Midia(dur, w and 1.inv(), h and 1.inv(), texto, fps)
    }

    private suspend fun processar(entrada: File, saida: File, o: Opcoes, m: Midia): Boolean {
        val querFsr = o.ampliar && o.metodoAmpliacao == MetodoAmpliacao.FSR
        var codec = o.codec
        // FSR roda na GPU e precisa do codificador do celular
        if (querFsr && codec == Codec.AV1) codec = Codec.H265
        if (codec == Codec.H265 && !Suporte.codec(Codec.H265)) codec = Codec.H264
        if (codec == Codec.H264 && !Suporte.codec(Codec.H264)) codec = Codec.AV1

        if (codec != Codec.AV1) {
            try {
                return rodarGpu(entrada, saida, o, m, codec)
            } catch (e: Cancelado) {
                throw e
            } catch (e: Throwable) {
                Log.e("FrameUp", "Caminho MediaCodec/GPU falhou; voltando para AV1", e)
                saida.delete()
            }
        }
        // AV1 (ou plano B): FSR vira Lanczos
        val oAv1 = if (o.metodoAmpliacao == MetodoAmpliacao.FSR) o.copy(metodoAmpliacao = MetodoAmpliacao.LANCZOS) else o
        return rodarAv1(entrada, saida, oAv1, m.duracaoMs)
    }

    private suspend fun rodarAv1(entrada: File, saida: File, o: Opcoes, duracaoMs: Double): Boolean {
        val est = Estimador(duracaoMs)
        return suspendCancellableCoroutine<Boolean> { cont ->
            val sessao = FFmpegKit.executeWithArgumentsAsync(
                montarArgumentos(entrada.absolutePath, saida.absolutePath, o),
                { s -> cont.resume(ReturnCode.isSuccess(s.returnCode)) },
                null,
                { st ->
                    est.atualizar(st.time.toDouble())?.let { (p, eta) ->
                        setProgressAsync(workDataOf("p" to p, "eta" to eta))
                        setForegroundAsync(info(p, eta))
                    }
                }
            )
            cont.invokeOnCancellation { FFmpegKit.cancel(sessao.sessionId) }
        }
    }

    private suspend fun rodarGpu(entrada: File, saida: File, o: Opcoes, m: Midia, codec: Codec): Boolean {
        val querFsr = o.ampliar && o.metodoAmpliacao == MetodoAmpliacao.FSR
        val (outW, outH) = if (o.ampliar) tamanhoSaida(m.srcW, m.srcH, o.altura) else m.srcW to m.srcH
        val fsrNaGpu = querFsr && outW > m.srcW && outH > m.srcH
        val frameW = if (o.ampliar && !fsrNaGpu) outW else m.srcW
        val frameH = if (o.ampliar && !fsrNaGpu) outH else m.srcH
        val fpsSaida = if (o.gerarQuadros) o.fps.toDouble() else m.fps

        val pipe = FFmpegKitConfig.registerNewFFmpegPipe(applicationContext)!!
        val args = argumentosBruto(entrada.absolutePath, pipe, o, m.srcW, m.srcH, outW, outH, fsrNaGpu, m.fpsTexto)
        val sessao = FFmpegKit.executeWithArgumentsAsync(args) { }
        // Se o trabalho for cancelado, derruba o FFmpeg (senão a leitura do pipe ficaria presa)
        val handle = currentCoroutineContext()[Job]?.invokeOnCompletion { FFmpegKit.cancel(sessao.sessionId) }
        val est = Estimador(m.duracaoMs)
        try {
            executarGpu(
                applicationContext, pipe, sessao, entrada, saida,
                ConfigGpu(frameW, frameH, outW, outH, fsrNaGpu, if (fsrNaGpu) stopsRcas(o.rcas) else null),
                fpsSaida, codec == Codec.H265,
                { isStopped },
                { feitoMs ->
                    est.atualizar(feitoMs)?.let { (p, eta) ->
                        setProgressAsync(workDataOf("p" to p, "eta" to eta))
                        setForegroundAsync(info(p, eta))
                    }
                }
            )
            return true
        } finally {
            handle?.dispose()
            FFmpegKit.cancel(sessao.sessionId)
            FFmpegKitConfig.closeFFmpegPipe(pipe)
        }
    }

    private fun salvarNaGaleria(arquivo: File) {
        val r = applicationContext.contentResolver
        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "frameup_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Melhorados")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = r.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)!!
        r.openOutputStream(uri)!!.use { out -> arquivo.inputStream().use { it.copyTo(out) } }
        v.clear(); v.put(MediaStore.Video.Media.IS_PENDING, 0)
        r.update(uri, v, null, null)
    }

    private fun info(p: Int, eta: Int): ForegroundInfo {
        val c = Idioma.aplicar(applicationContext)
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(canal, c.getString(R.string.notif_canal), NotificationManager.IMPORTANCE_LOW)
        )
        val n = NotificationCompat.Builder(c, canal)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle(c.getString(R.string.notif_titulo_fmt, p))
            .setContentText(Idioma.etaTexto(c, eta))
            .setProgress(100, p, false)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
        return ForegroundInfo(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
    }
}
