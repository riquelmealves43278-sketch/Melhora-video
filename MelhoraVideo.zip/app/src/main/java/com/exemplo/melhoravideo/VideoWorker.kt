package com.exemplo.melhoravideo

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentValues
import android.content.Context
import android.content.pm.ServiceInfo
import android.net.Uri
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.work.*
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume

class VideoWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    private val canal = "processamento"

    override suspend fun doWork(): Result {
        val c = applicationContext
        val opcoes = Opcoes(
            altura = inputData.getInt("altura", 1080),
            fps = inputData.getInt("fps", 60),
            ampliar = inputData.getBoolean("ampliar", true),
            gerarQuadros = inputData.getBoolean("gerar", true),
            metodoAmpliacao = runCatching { MetodoAmpliacao.valueOf(inputData.getString("mamp") ?: "") }
                .getOrDefault(MetodoAmpliacao.LANCZOS_NITIDEZ),
            metodoQuadros = runCatching { MetodoQuadros.valueOf(inputData.getString("mqua") ?: "") }
                .getOrDefault(MetodoQuadros.QUALIDADE)
        )
        val entrada = File(c.cacheDir, "entrada.mp4")
        val saida = File(c.cacheDir, "saida.mp4")
        setForeground(info(0, -1))

        try {
            // Copia o vídeo escolhido para o cache (simples e evita problemas de SAF)
            c.contentResolver.openInputStream(Uri.parse(inputData.getString("uri")!!))!!.use { i ->
                entrada.outputStream().use { i.copyTo(it) }
            }
            val duracaoMs = (FFprobeKit.getMediaInformation(entrada.absolutePath)
                .mediaInformation?.duration?.toDoubleOrNull() ?: 0.0) * 1000

            val inicio = System.currentTimeMillis()
            var etaSuave = -1.0
            var ultimoP = -1

            val ok = suspendCancellableCoroutine<Boolean> { cont ->
                val sessao = FFmpegKit.executeWithArgumentsAsync(
                    montarArgumentos(entrada.absolutePath, saida.absolutePath, opcoes),
                    { s -> cont.resume(ReturnCode.isSuccess(s.returnCode)) },
                    null,
                    { st ->
                        if (duracaoMs > 0) {
                            val feito = st.time.toDouble()
                            val p = (feito / duracaoMs * 100).toInt().coerceIn(0, 99)
                            if (p != ultimoP) {
                                ultimoP = p
                                val decorrido = System.currentTimeMillis() - inicio
                                var eta = -1
                                // Só estima depois de alguns segundos de trabalho; suaviza as oscilações
                                if (feito > 0 && decorrido > 5000) {
                                    val bruto = (duracaoMs - feito) * decorrido / feito / 1000.0
                                    etaSuave = if (etaSuave < 0) bruto else etaSuave * 0.8 + bruto * 0.2
                                    eta = etaSuave.toInt()
                                }
                                setProgressAsync(workDataOf("p" to p, "eta" to eta))
                                setForegroundAsync(info(p, eta))
                            }
                        }
                    }
                )
                cont.invokeOnCancellation { FFmpegKit.cancel(sessao.sessionId) }
            }
            if (!ok) return Result.failure()

            salvarNaGaleria(saida)
            setProgress(workDataOf("p" to 100, "eta" to 0))
            return Result.success()
        } finally {
            entrada.delete(); saida.delete()
        }
    }

    private fun salvarNaGaleria(arquivo: File) {
        val r = applicationContext.contentResolver
        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "frameup_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Melhorados")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = r.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)!!
        r.openOutputStream(uri)!!.use { out -> arquivo.inputStream().use { it.copyTo(out) } }
        v.clear(); v.put(MediaStore.Video.Media.IS_PENDING, 0)
        r.update(uri, v, null, null)
    }

    private fun info(p: Int, eta: Int): ForegroundInfo {
        val c = Idioma.aplicar(applicationContext)
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(canal, c.getString(R.string.notif_canal), NotificationManager.IMPORTANCE_LOW)
        )
        val n = NotificationCompat.Builder(c, canal)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle(c.getString(R.string.notif_titulo_fmt, p))
            .setContentText(Idioma.etaTexto(c, eta))
            .setProgress(100, p, false)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
        return ForegroundInfo(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
    }
}
